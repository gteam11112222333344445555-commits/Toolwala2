// Login, Signup and Forgot Password pages (data saved in localStorage).
import { useState, type FormEvent, type ReactNode } from "react";
import { Btn, Card, Field, inputCls } from "../components/ui";
import { Logo } from "../components/Logo";
import { ADMIN_EMAIL, ADMIN_PASSWORD, login, resetPassword, setAdmin, signup, useCurrentUser } from "../lib/store";
import { toast } from "../lib/helpers";

function AuthShell({ title, subtitle, children }: { title: string; subtitle: string; children: ReactNode }) {
  return (
    <div className="flex min-h-[70vh] items-center justify-center px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-6 flex justify-center">
          <Logo size="lg" />
        </div>
        <Card>
          <h1 className="text-center text-2xl font-extrabold text-slate-900">{title}</h1>
          <p className="mb-6 mt-1 text-center text-sm text-slate-600">{subtitle}</p>
          {children}
        </Card>
      </div>
    </div>
  );
}

export function LoginPage() {
  const user = useCurrentUser();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const submit = (e: FormEvent) => {
    e.preventDefault();
    setError("");
    if (email.trim().toLowerCase() === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
      setAdmin(true);
      toast("Admin login successful");
      window.location.hash = "#/admin";
      return;
    }
    const err = login(email, password);
    if (err) {
      setError(err);
      return;
    }
    toast("Login successful! Welcome back");
    window.location.hash = "#/";
  };

  return (
    <AuthShell title="Login" subtitle="Apne account se login karein">
      {user && (
        <p className="mb-4 rounded-xl bg-emerald-50 p-3 text-center text-sm font-semibold text-emerald-700">
          Aap already login hain: {user.name}
        </p>
      )}
      <form onSubmit={submit} className="space-y-4">
        <Field label="Email">
          <input
            type="email"
            className={inputCls}
            placeholder="you@example.com"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </Field>
        <Field label="Password">
          <input
            type="password"
            className={inputCls}
            placeholder="Apna password"
            autoComplete="current-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Field>
        {error && <p className="rounded-lg bg-red-50 p-2 text-sm font-semibold text-red-600">{error}</p>}
        <Btn type="submit" className="w-full">
          🔐 Login
        </Btn>
        <div className="text-right">
          <a href="#/forgot" className="text-sm font-bold text-violet-700 hover:underline">
            Forgot Password?
          </a>
        </div>
      </form>

      <div className="my-6 flex items-center gap-3 text-xs text-slate-400">
        <span className="h-px flex-1 bg-slate-200" />
        NAYA ACCOUNT?
        <span className="h-px flex-1 bg-slate-200" />
      </div>
      <a href="#/signup" className="block">
        <Btn variant="secondary" className="w-full">
          ✨ Signup
        </Btn>
      </a>
    </AuthShell>
  );
}

export function SignupPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const err = signup(name, email, password);
    if (err) {
      setError(err);
      return;
    }
    toast(`Account ban gaya! Welcome, ${name.trim()}`);
    window.location.hash = "#/";
  };

  return (
    <AuthShell title="Signup" subtitle="Free account banayein aur history save karein">
      <form onSubmit={submit} className="space-y-4">
        <Field label="Name">
          <input
            className={inputCls}
            placeholder="Aapka naam"
            autoComplete="name"
            maxLength={40}
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </Field>
        <Field label="Email">
          <input
            type="email"
            className={inputCls}
            placeholder="you@example.com"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </Field>
        <Field label="Password">
          <input
            type="password"
            className={inputCls}
            placeholder="Kam az kam 6 characters"
            autoComplete="new-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Field>
        {error && <p className="rounded-lg bg-red-50 p-2 text-sm font-semibold text-red-600">{error}</p>}
        <Btn type="submit" className="w-full">
          ✨ Signup
        </Btn>
      </form>
      <p className="mt-5 text-center text-sm text-slate-600">
        Account pehle se hai?{" "}
        <a href="#/login" className="font-bold text-violet-700 hover:underline">
          Login karein
        </a>
      </p>
    </AuthShell>
  );
}

export function ForgotPage() {
  const [email, setEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [error, setError] = useState("");

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const err = resetPassword(email, newPassword);
    if (err) {
      setError(err);
      return;
    }
    toast("Password reset ho gaya. Ab login karein");
    window.location.hash = "#/login";
  };

  return (
    <AuthShell
      title="Forgot Password"
      subtitle="Is free version mein email nahi jata, isliye naya password yahin set karein."
    >
      <form onSubmit={submit} className="space-y-4">
        <Field label="Registered Email">
          <input
            type="email"
            className={inputCls}
            placeholder="you@example.com"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </Field>
        <Field label="Naya Password">
          <input
            type="password"
            className={inputCls}
            placeholder="Kam az kam 6 characters"
            required
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
          />
        </Field>
        {error && <p className="rounded-lg bg-red-50 p-2 text-sm font-semibold text-red-600">{error}</p>}
        <Btn type="submit" className="w-full">
          🔑 Reset Password
        </Btn>
      </form>
      <p className="mt-5 text-center text-sm">
        <a href="#/login" className="font-bold text-violet-700 hover:underline">
          ← Login par wapas jayein
        </a>
      </p>
    </AuthShell>
  );
}
