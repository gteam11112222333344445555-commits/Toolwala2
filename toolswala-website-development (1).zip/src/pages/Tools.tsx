// Tools listing page and the single tool page (/#/tools/<id>).
import type { ComponentType } from "react";
import { ToolCard } from "../components/ToolCard";
import { AdBox } from "../components/AdBox";
import { Card, LinkBtn, PageTitle } from "../components/ui";
import { TOOLS } from "../lib/content";
import { useCurrentUser, useSettings, type ToolId } from "../lib/store";
import PaletteTool from "../tools/PaletteTool";
import MemeTool from "../tools/MemeTool";
import DomainTool from "../tools/DomainTool";
import WorkoutTool from "../tools/WorkoutTool";
import StoryTool from "../tools/StoryTool";
import EssayTool from "../tools/EssayTool";

const COMPONENTS: Record<ToolId, ComponentType> = {
  palette: PaletteTool,
  meme: MemeTool,
  domain: DomainTool,
  workout: WorkoutTool,
  story: StoryTool,
  essay: EssayTool,
};

export function ToolsPage() {
  const settings = useSettings();
  return (
    <section className="mx-auto max-w-6xl px-4 py-10">
      <PageTitle icon="🧰" title="All Tools" subtitle="Sab tools 100% free hain. Koi bhi tool chalayein." />
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {TOOLS.map((t) => (
          <ToolCard key={t.id} tool={t} enabled={settings.tools[t.id]} />
        ))}
      </div>
    </section>
  );
}

export function ToolPage({ id }: { id: string }) {
  const settings = useSettings();
  const user = useCurrentUser();
  const tool = TOOLS.find((t) => t.id === id);

  if (!tool) {
    return (
      <div className="mx-auto max-w-md px-4 py-20 text-center">
        <div className="text-6xl">🤷</div>
        <h1 className="mt-4 text-2xl font-extrabold">Tool nahi mila</h1>
        <div className="mt-6">
          <LinkBtn href="#/tools">Sab Tools Dekhein</LinkBtn>
        </div>
      </div>
    );
  }

  const Comp = COMPONENTS[tool.id];
  const enabled = settings.tools[tool.id];

  return (
    <section className="mx-auto max-w-4xl px-4 py-8">
      <a href="#/tools" className="text-sm font-bold text-violet-700 hover:underline">
        ← Back to Tools
      </a>

      <div className="mt-4 flex items-center gap-4">
        <div
          className={`flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br ${tool.gradient} text-3xl shadow-lg`}
        >
          {tool.icon}
        </div>
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 sm:text-3xl">{tool.name}</h1>
          <p className="text-sm text-slate-600">{tool.detail}</p>
        </div>
      </div>

      {!user && (
        <div className="mt-5 rounded-xl bg-sky-50 p-3 text-sm text-sky-800 ring-1 ring-sky-200">
          ℹ️ Aap login nahi hain. Tool bilkul free hai, lekin history save nahi hogi.{" "}
          <a href="#/login" className="font-bold underline">
            Login karein
          </a>
        </div>
      )}

      <div className="mt-6">
        {enabled ? (
          <Comp />
        ) : (
          <Card>
            <p className="text-center font-semibold text-slate-700">
              🔒 Ye tool abhi admin ne band kiya hua hai. Thori der baad dobara try karein.
            </p>
          </Card>
        )}
      </div>

      {settings.adsOn && <AdBox code={settings.adCode} />}
    </section>
  );
}
