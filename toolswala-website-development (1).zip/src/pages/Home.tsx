// Homepage: hero banner, tool cards, ads (if ON), latest blog posts and features.
import { ToolCard } from "../components/ToolCard";
import { AdBox } from "../components/AdBox";
import { TOOLS, asset } from "../lib/content";
import { formatDate } from "../lib/helpers";
import { useBlog, useCurrentUser, useSettings } from "../lib/store";

export default function Home() {
  const settings = useSettings();
  const user = useCurrentUser();
  const blog = useBlog();
  const latest = [...blog].sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, 3);

  return (
    <div>
      {/* Hero */}
      <section className="relative isolate overflow-hidden">
        <img
          src={asset("hero.jpg")}
          alt="ToolsWala tools banner"
          className="absolute inset-0 -z-20 h-full w-full object-cover"
        />
        <div className="absolute inset-0 -z-10 bg-gradient-to-br from-violet-900/90 via-fuchsia-800/80 to-orange-600/70" />
        <div className="mx-auto max-w-6xl px-4 py-16 text-center text-white sm:py-24 md:text-left">
          <span className="inline-block rounded-full bg-white/15 px-4 py-1.5 text-xs font-bold tracking-wide ring-1 ring-white/30 backdrop-blur">
            🆓 100% FREE • No Payment • No Paid Service
          </span>
          <h1 className="mt-5 text-4xl font-black leading-tight sm:text-5xl lg:text-6xl">
            Sab Free Tools,
            <br />
            <span className="text-yellow-300">Ek Jagah</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base text-white/90 sm:text-lg md:mx-0">{settings.heroText}</p>
          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row md:justify-start">
            <a
              href="#/tools"
              className="rounded-xl bg-white px-6 py-3 text-center text-sm font-bold text-violet-700 shadow-lg transition hover:bg-yellow-50 active:scale-95"
            >
              🚀 Explore Tools
            </a>
            {user ? (
              <a
                href="#/history"
                className="rounded-xl bg-white/15 px-6 py-3 text-center text-sm font-bold text-white ring-1 ring-white/40 backdrop-blur transition hover:bg-white/25 active:scale-95"
              >
                📚 My History
              </a>
            ) : (
              <a
                href="#/signup"
                className="rounded-xl bg-white/15 px-6 py-3 text-center text-sm font-bold text-white ring-1 ring-white/40 backdrop-blur transition hover:bg-white/25 active:scale-95"
              >
                ✨ Signup Free
              </a>
            )}
          </div>
        </div>
      </section>

      {/* Tools */}
      <section id="tools" className="mx-auto max-w-6xl px-4 py-12 sm:py-16">
        <div className="mb-8 text-center">
          <h2 className="text-2xl font-extrabold text-slate-900 sm:text-3xl">Hamare Tools</h2>
          <p className="mt-2 text-slate-600">Har tool ke andar "Use Tool" dabayein aur shuru karein.</p>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {TOOLS.map((t) => (
            <ToolCard key={t.id} tool={t} enabled={settings.tools[t.id]} />
          ))}
        </div>
      </section>

      {settings.adsOn && (
        <div className="mx-auto max-w-6xl px-4">
          <AdBox code={settings.adCode} />
        </div>
      )}

      {/* Features */}
      <section className="mx-auto grid max-w-6xl gap-4 px-4 py-6 sm:grid-cols-3">
        {[
          { icon: "💯", title: "100% Free", text: "Koi paid plan ya hidden charge nahi." },
          { icon: "📱", title: "Mobile Friendly", text: "Phone, tablet aur computer, sab par chalta hai." },
          { icon: "🗂️", title: "Apni History", text: "Login karein aur apne results baad mein dekhein." },
        ].map((f) => (
          <div key={f.title} className="rounded-2xl bg-white p-5 text-center shadow-sm ring-1 ring-slate-200">
            <div className="text-4xl">{f.icon}</div>
            <h3 className="mt-2 font-bold text-slate-900">{f.title}</h3>
            <p className="mt-1 text-sm text-slate-600">{f.text}</p>
          </div>
        ))}
      </section>

      {/* Blog preview */}
      {latest.length > 0 && (
        <section className="mx-auto max-w-6xl px-4 py-10">
          <div className="mb-5 flex items-center justify-between">
            <h2 className="text-2xl font-extrabold text-slate-900">Latest Blog</h2>
            <a href="#/blog" className="text-sm font-bold text-violet-700 hover:underline">
              Sab dekhein →
            </a>
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            {latest.map((p) => (
              <article key={p.id} className="rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
                <p className="text-xs font-semibold text-slate-400">{formatDate(p.date)}</p>
                <h3 className="mt-1 font-bold text-slate-900">{p.title}</h3>
                <p className="mt-2 line-clamp-3 text-sm text-slate-600">{p.body}</p>
              </article>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
