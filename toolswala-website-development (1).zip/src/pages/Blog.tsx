// Public blog page. Posts are added / deleted from the Admin Panel.
import { PageTitle, Card } from "../components/ui";
import { formatDate } from "../lib/helpers";
import { useBlog } from "../lib/store";

export default function BlogPage() {
  const posts = useBlog();
  const sorted = [...posts].sort((a, b) => (a.date < b.date ? 1 : -1));

  return (
    <section className="mx-auto max-w-3xl px-4 py-10">
      <PageTitle icon="📝" title="Blog" subtitle="Tools, tips aur ToolsWala ki nayi khabrein." />
      {sorted.length === 0 ? (
        <Card>
          <p className="text-center text-slate-600">Abhi koi post nahi hai.</p>
        </Card>
      ) : (
        <div className="space-y-5">
          {sorted.map((p) => (
            <Card key={p.id} className="fade-in">
              <p className="text-xs font-semibold uppercase tracking-wide text-violet-600">{formatDate(p.date)}</p>
              <h2 className="mt-1 text-xl font-extrabold text-slate-900">{p.title}</h2>
              <p className="mt-3 whitespace-pre-line leading-relaxed text-slate-700">{p.body}</p>
            </Card>
          ))}
        </div>
      )}
    </section>
  );
}
