// My History: logged-in users can see, copy, delete and clear their saved tool results.
import { useState } from "react";
import { Btn, Card, PageTitle, LinkBtn } from "../components/ui";
import { TOOLS } from "../lib/content";
import { copyText, formatDate, toast } from "../lib/helpers";
import { getHistory, saveHistory, useCurrentUser, useHistory, type ToolId } from "../lib/store";

export default function HistoryPage() {
  const user = useCurrentUser();
  const all = useHistory();
  const [filter, setFilter] = useState<"all" | ToolId>("all");

  if (!user) {
    return (
      <section className="mx-auto max-w-md px-4 py-20 text-center">
        <div className="text-6xl">🔒</div>
        <h1 className="mt-4 text-2xl font-extrabold">Login zaroori hai</h1>
        <p className="mt-2 text-slate-600">History dekhne ke liye pehle login karein.</p>
        <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
          <LinkBtn href="#/login">Login</LinkBtn>
          <LinkBtn href="#/signup" variant="secondary">
            Signup
          </LinkBtn>
        </div>
      </section>
    );
  }

  const mine = all.filter((h) => h.userEmail === user.email && (filter === "all" || h.tool === filter));

  const remove = (id: string) => {
    saveHistory(getHistory().filter((h) => h.id !== id));
    toast("Deleted from History");
  };

  const clearAll = () => {
    if (!window.confirm("Aapki sari history delete ho jayegi. Pakka?")) return;
    saveHistory(getHistory().filter((h) => h.userEmail !== user.email));
    toast("History cleared");
  };

  const toolName = (id: ToolId) => TOOLS.find((t) => t.id === id)?.name ?? id;
  const toolIcon = (id: ToolId) => TOOLS.find((t) => t.id === id)?.icon ?? "🔧";

  return (
    <section className="mx-auto max-w-4xl px-4 py-10">
      <PageTitle icon="📚" title="My History" subtitle={`${user.name}, yahan aapke tools ke saved results hain.`} />

      <Card className="mb-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setFilter("all")}
              className={`cursor-pointer rounded-full px-3 py-1.5 text-xs font-bold ${
                filter === "all" ? "bg-violet-600 text-white" : "bg-slate-100 text-slate-600"
              }`}
            >
              All ({all.filter((h) => h.userEmail === user.email).length})
            </button>
            {TOOLS.map((t) => (
              <button
                key={t.id}
                onClick={() => setFilter(t.id)}
                className={`cursor-pointer rounded-full px-3 py-1.5 text-xs font-bold ${
                  filter === t.id ? "bg-violet-600 text-white" : "bg-slate-100 text-slate-600"
                }`}
              >
                {t.icon} {t.name.split(" ")[0]}
              </button>
            ))}
          </div>
          <Btn variant="danger" onClick={clearAll} className="w-full sm:w-auto">
            🗑️ Clear All
          </Btn>
        </div>
      </Card>

      {mine.length === 0 ? (
        <Card>
          <p className="py-8 text-center text-slate-600">
            Abhi koi history nahi hai. Koi tool use karein, result yahan save ho jayega.
          </p>
          <div className="flex justify-center">
            <LinkBtn href="#/tools">🧰 Tools Dekhein</LinkBtn>
          </div>
        </Card>
      ) : (
        <div className="space-y-4">
          {mine.map((h) => (
            <Card key={h.id} className="fade-in">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <p className="font-bold text-slate-900">
                    {toolIcon(h.tool)} {toolName(h.tool)}
                  </p>
                  <p className="text-xs text-slate-500">📅 {formatDate(h.date)}</p>
                </div>
                <div className="flex gap-2">
                  <Btn
                    variant="secondary"
                    className="!px-3 !py-1.5 text-xs"
                    onClick={async () => (await copyText(h.result)) && toast("Result copied!")}
                  >
                    📋 Copy
                  </Btn>
                  <Btn variant="danger" className="!px-3 !py-1.5 text-xs" onClick={() => remove(h.id)}>
                    🗑️ Delete
                  </Btn>
                </div>
              </div>
              <pre className="mt-3 max-h-56 overflow-auto whitespace-pre-wrap break-words rounded-xl bg-slate-50 p-3 font-sans text-sm text-slate-700 ring-1 ring-slate-200">
                {h.result}
              </pre>
            </Card>
          ))}
        </div>
      )}
    </section>
  );
}
