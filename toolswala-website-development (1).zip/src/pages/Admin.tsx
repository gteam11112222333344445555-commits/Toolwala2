// Admin Panel (open with #/admin). Login: admin@toolswala.com / admin123
// Dashboard, Users (Block/Unblock/Delete), Tools ON/OFF, Content, Ads, Blog, API Key, History, Backup.
import { useState, type FormEvent, type ReactNode } from "react";
import { Btn, Card, Field, inputCls, Switch } from "../components/ui";
import { Logo } from "../components/Logo";
import { TOOLS } from "../lib/content";
import { downloadText, formatDate, toast, uid } from "../lib/helpers";
import {
  ADMIN_EMAIL,
  ADMIN_PASSWORD,
  exportAllData,
  getBlog,
  getHistory,
  getUsers,
  saveBlog,
  saveHistory,
  saveSettings,
  saveUsers,
  setAdmin,
  todayKey,
  useBlog,
  useHistory,
  useIsAdmin,
  useSettings,
  useUsage,
  useUsers,
  useVisits,
  type User,
} from "../lib/store";

type Tab = "dashboard" | "users" | "tools" | "content" | "ads" | "blog" | "api" | "history" | "backup";

const TABS: { id: Tab; label: string }[] = [
  { id: "dashboard", label: "📊 Dashboard" },
  { id: "users", label: "👥 Users" },
  { id: "tools", label: "🧰 Tools" },
  { id: "content", label: "✏️ Content" },
  { id: "ads", label: "📢 Ads" },
  { id: "blog", label: "📝 Blog" },
  { id: "api", label: "🔑 API Key" },
  { id: "history", label: "📚 History" },
  { id: "backup", label: "💾 Backup" },
];

export default function AdminPage() {
  const isAdmin = useIsAdmin();
  return isAdmin ? <AdminPanel /> : <AdminLogin />;
}

function AdminLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (email.trim().toLowerCase() === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
      setAdmin(true);
      setError("");
      toast("Admin login successful");
    } else {
      setError("Admin email ya password galat hai.");
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-900 via-violet-950 to-slate-900 px-4">
      <div className="w-full max-w-sm">
        <div className="mb-6 flex flex-col items-center gap-3">
          <Logo size="lg" light />
          <p className="text-sm text-violet-200">Admin Panel Login</p>
        </div>
        <Card>
          <form onSubmit={submit} className="space-y-4">
            <Field label="Admin Email">
              <input
                type="email"
                className={inputCls}
                autoComplete="username"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </Field>
            <Field label="Password">
              <input
                type="password"
                className={inputCls}
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </Field>
            {error && <p className="rounded-lg bg-red-50 p-2 text-sm font-semibold text-red-600">{error}</p>}
            <Btn type="submit" className="w-full">
              🔐 Admin Login
            </Btn>
          </form>
          <a href="#/" className="mt-5 block text-center text-sm font-bold text-violet-700 hover:underline">
            ← Website par wapas jayein
          </a>
        </Card>
      </div>
    </div>
  );
}

function AdminPanel() {
  const [tab, setTab] = useState<Tab>("dashboard");

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="sticky top-0 z-20 flex items-center justify-between gap-3 bg-slate-900 px-4 py-3">
        <div className="flex items-center gap-3">
          <Logo size="sm" light />
          <span className="rounded-md bg-violet-600 px-2 py-0.5 text-xs font-bold text-white">ADMIN</span>
        </div>
        <div className="flex items-center gap-2">
          <a href="#/" className="rounded-lg px-3 py-2 text-sm font-semibold text-violet-200 hover:bg-white/10">
            View Site
          </a>
          <button
            onClick={() => {
              setAdmin(false);
              toast("Admin logged out");
            }}
            className="cursor-pointer rounded-lg bg-red-500 px-3 py-2 text-sm font-semibold text-white hover:bg-red-600"
          >
            Logout
          </button>
        </div>
      </header>

      <div className="mx-auto flex max-w-6xl flex-col gap-4 p-4 md:flex-row md:gap-6">
        <nav className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 md:mx-0 md:w-56 md:shrink-0 md:flex-col md:overflow-visible md:px-0">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`shrink-0 cursor-pointer whitespace-nowrap rounded-xl px-4 py-2.5 text-left text-sm font-semibold transition ${
                tab === t.id
                  ? "bg-violet-600 text-white shadow-md"
                  : "bg-white text-slate-700 ring-1 ring-slate-200 hover:bg-violet-50"
              }`}
            >
              {t.label}
            </button>
          ))}
        </nav>

        <main className="min-w-0 flex-1">
          {tab === "dashboard" && <Dashboard />}
          {tab === "users" && <UsersTab />}
          {tab === "tools" && <ToolsTab />}
          {tab === "content" && <ContentTab />}
          {tab === "ads" && <AdsTab />}
          {tab === "blog" && <BlogTab />}
          {tab === "api" && <ApiKeyTab />}
          {tab === "history" && <HistoryTab />}
          {tab === "backup" && <BackupTab />}
        </main>
      </div>
    </div>
  );
}

function Stat({ label, value, sub, icon }: { label: string; value: ReactNode; sub?: string; icon: string }) {
  return (
    <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200 sm:p-5">
      <div className="flex items-center justify-between">
        <span className="text-xs font-bold uppercase tracking-wide text-slate-500">{label}</span>
        <span className="text-2xl">{icon}</span>
      </div>
      <div className="mt-2 break-words text-xl font-extrabold text-slate-900 sm:text-2xl">{value}</div>
      {sub && <div className="mt-1 text-xs text-slate-500">{sub}</div>}
    </div>
  );
}

function Dashboard() {
  const users = useUsers();
  const visits = useVisits();
  const usage = useUsage();
  const history = useHistory();

  const todayVisitors = visits[todayKey()] ?? 0;
  const totalVisits = Object.values(visits).reduce((a, b) => a + b, 0);
  const ranked = TOOLS.map((t) => ({ ...t, count: usage[t.id] ?? 0 })).sort((a, b) => b.count - a.count);
  const top = ranked[0] && ranked[0].count > 0 ? ranked[0] : null;
  const max = Math.max(1, ...ranked.map((r) => r.count));

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Total Users" value={users.length} icon="👥" />
        <Stat label="Today Visitors" value={todayVisitors} sub={`Total visits: ${totalVisits}`} icon="🧑‍💻" />
        <Stat
          label="Most Used Tool"
          value={top ? top.name : "—"}
          sub={top ? `${top.count} uses` : "Abhi koi use nahi"}
          icon="🏆"
        />
        <Stat label="Total History" value={history.length} sub="Sab users ki saved entries" icon="📚" />
      </div>

      <Card>
        <h2 className="mb-4 text-lg font-bold text-slate-900">Tool Usage</h2>
        <div className="space-y-3">
          {ranked.map((r) => (
            <div key={r.id}>
              <div className="mb-1 flex justify-between text-sm">
                <span className="font-semibold text-slate-700">
                  {r.icon} {r.name}
                </span>
                <span className="font-bold text-violet-700">{r.count}</span>
              </div>
              <div className="h-2.5 overflow-hidden rounded-full bg-slate-200">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-500 transition-all"
                  style={{ width: `${(r.count / max) * 100}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function UsersTab() {
  const users = useUsers();

  const update = (email: string, patch: Partial<User>) => {
    saveUsers(getUsers().map((u) => (u.email === email ? { ...u, ...patch } : u)));
    toast(patch.blocked ? "User blocked" : "User unblocked");
  };

  const remove = (email: string) => {
    if (!window.confirm(`${email} ko delete karna hai? Iski history bhi delete ho jayegi.`)) return;
    saveUsers(getUsers().filter((u) => u.email !== email));
    saveHistory(getHistory().filter((h) => h.userEmail !== email));
    toast("User deleted");
  };

  if (users.length === 0) {
    return <Card><p className="py-6 text-center text-slate-600">Abhi koi user register nahi hua.</p></Card>;
  }

  return (
    <Card>
      <h2 className="mb-4 text-lg font-bold text-slate-900">Users ({users.length})</h2>
      <div className="space-y-3">
        {users.map((u) => (
          <div
            key={u.email}
            className="flex flex-col gap-3 rounded-xl bg-slate-50 p-3 ring-1 ring-slate-200 sm:flex-row sm:items-center sm:justify-between"
          >
            <div className="min-w-0">
              <p className="flex flex-wrap items-center gap-2 font-bold text-slate-900">
                <span className="truncate">{u.name}</span>
                {u.blocked ? (
                  <span className="rounded-full bg-red-100 px-2 py-0.5 text-xs text-red-700">Blocked</span>
                ) : (
                  <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-xs text-emerald-700">Active</span>
                )}
              </p>
              <p className="truncate text-sm text-slate-600">{u.email}</p>
              <p className="text-xs text-slate-400">Joined: {formatDate(u.createdAt)}</p>
            </div>
            <div className="flex shrink-0 gap-2">
              {u.blocked ? (
                <Btn variant="success" className="!px-3 !py-2 text-xs" onClick={() => update(u.email, { blocked: false })}>
                  Unblock
                </Btn>
              ) : (
                <Btn variant="secondary" className="!px-3 !py-2 text-xs" onClick={() => update(u.email, { blocked: true })}>
                  Block
                </Btn>
              )}
              <Btn variant="danger" className="!px-3 !py-2 text-xs" onClick={() => remove(u.email)}>
                Delete
              </Btn>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

function ToolsTab() {
  const settings = useSettings();
  return (
    <Card>
      <h2 className="mb-1 text-lg font-bold text-slate-900">Tools ON / OFF</h2>
      <p className="mb-4 text-sm text-slate-500">Off karne par tool website par band dikhega.</p>
      <div className="space-y-3">
        {TOOLS.map((t) => (
          <div key={t.id} className="flex items-center justify-between rounded-xl bg-slate-50 p-3 ring-1 ring-slate-200">
            <span className="font-semibold text-slate-800">
              {t.icon} {t.name}
            </span>
            <div className="flex items-center gap-3">
              <span className={`text-xs font-bold ${settings.tools[t.id] ? "text-emerald-600" : "text-slate-400"}`}>
                {settings.tools[t.id] ? "ON" : "OFF"}
              </span>
              <Switch
                label={`Toggle ${t.name}`}
                checked={settings.tools[t.id]}
                onChange={(v) => {
                  saveSettings({ tools: { ...settings.tools, [t.id]: v } });
                  toast(`${t.name}: ${v ? "ON" : "OFF"}`);
                }}
              />
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

function ContentTab() {
  const settings = useSettings();
  const [siteName, setSiteName] = useState(settings.siteName);
  const [logoLetter, setLogoLetter] = useState(settings.logoLetter);
  const [heroText, setHeroText] = useState(settings.heroText);

  const save = () => {
    saveSettings({
      siteName: siteName.trim() || "ToolsWala",
      logoLetter: (logoLetter.trim() || "W").slice(0, 1),
      heroText: heroText.trim(),
    });
    toast("Content saved");
  };

  return (
    <Card>
      <h2 className="mb-4 text-lg font-bold text-slate-900">Website Content</h2>
      <div className="space-y-4">
        <div className="flex items-center gap-4 rounded-xl bg-slate-50 p-4 ring-1 ring-slate-200">
          <span className="text-sm font-semibold text-slate-600">Preview:</span>
          <Logo />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Website Name (Logo text)">
            <input className={inputCls} maxLength={30} value={siteName} onChange={(e) => setSiteName(e.target.value)} />
          </Field>
          <Field label="Logo Letter (box mein)">
            <input
              className={inputCls}
              maxLength={1}
              value={logoLetter}
              onChange={(e) => setLogoLetter(e.target.value)}
            />
          </Field>
        </div>
        <p className="-mt-2 text-xs text-slate-500">
          Tip: Logo letter naam mein se hona chahiye (jaise "W" in "ToolsWala") taake W colorful box mein dikhe.
        </p>
        <Field label="Homepage Text (Hero)">
          <textarea
            className={inputCls}
            rows={4}
            maxLength={300}
            value={heroText}
            onChange={(e) => setHeroText(e.target.value)}
          />
        </Field>
        <Btn onClick={save}>💾 Save Content</Btn>
      </div>
    </Card>
  );
}

function AdsTab() {
  const settings = useSettings();
  const [code, setCode] = useState(settings.adCode);

  return (
    <Card>
      <h2 className="mb-1 text-lg font-bold text-slate-900">Ads</h2>
      <p className="mb-4 text-sm text-slate-500">
        Ads ON karne par Home aur Tool pages par ad box dikhega. Ad code paste karein (jaise free AdSense code).
      </p>
      <div className="space-y-4">
        <div className="flex items-center justify-between rounded-xl bg-slate-50 p-4 ring-1 ring-slate-200">
          <span className="font-semibold text-slate-800">Ads Status: {settings.adsOn ? "ON" : "OFF"}</span>
          <Switch
            label="Toggle ads"
            checked={settings.adsOn}
            onChange={(v) => {
              saveSettings({ adsOn: v });
              toast(`Ads ${v ? "ON" : "OFF"}`);
            }}
          />
        </div>
        <Field label="Ad HTML Code (optional)">
          <textarea
            className={`${inputCls} font-mono text-xs`}
            rows={5}
            placeholder="<script>...</script>"
            value={code}
            onChange={(e) => setCode(e.target.value)}
          />
        </Field>
        <Btn
          onClick={() => {
            saveSettings({ adCode: code });
            toast("Ad code saved");
          }}
        >
          💾 Save Ad Code
        </Btn>
      </div>
    </Card>
  );
}

function BlogTab() {
  const posts = useBlog();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");

  const add = () => {
    if (!title.trim() || !body.trim()) return toast("Title aur body dono likhein");
    saveBlog([{ id: uid(), title: title.trim(), body: body.trim(), date: new Date().toISOString() }, ...getBlog()]);
    setTitle("");
    setBody("");
    toast("Blog post added");
  };

  const remove = (id: string) => {
    if (!window.confirm("Ye post delete karna hai?")) return;
    saveBlog(getBlog().filter((p) => p.id !== id));
    toast("Post deleted");
  };

  return (
    <div className="space-y-5">
      <Card>
        <h2 className="mb-4 text-lg font-bold text-slate-900">Naya Blog Post</h2>
        <div className="space-y-4">
          <Field label="Title">
            <input className={inputCls} maxLength={120} value={title} onChange={(e) => setTitle(e.target.value)} />
          </Field>
          <Field label="Body">
            <textarea className={inputCls} rows={5} value={body} onChange={(e) => setBody(e.target.value)} />
          </Field>
          <Btn onClick={add}>➕ Add Post</Btn>
        </div>
      </Card>
      <Card>
        <h2 className="mb-4 text-lg font-bold text-slate-900">Posts ({posts.length})</h2>
        <div className="space-y-3">
          {posts.map((p) => (
            <div key={p.id} className="flex items-start justify-between gap-3 rounded-xl bg-slate-50 p-3 ring-1 ring-slate-200">
              <div className="min-w-0">
                <p className="truncate font-bold text-slate-900">{p.title}</p>
                <p className="text-xs text-slate-400">{formatDate(p.date)}</p>
              </div>
              <Btn variant="danger" className="!px-3 !py-2 text-xs" onClick={() => remove(p.id)}>
                Delete
              </Btn>
            </div>
          ))}
          {posts.length === 0 && <p className="text-center text-sm text-slate-500">Koi post nahi hai.</p>}
        </div>
      </Card>
    </div>
  );
}

function ApiKeyTab() {
  const settings = useSettings();
  const [key, setKey] = useState("");
  const hasKey = settings.apiKey.length > 0;

  return (
    <Card>
      <h2 className="mb-1 text-lg font-bold text-slate-900">Gemini API Key</h2>
      <p className="mb-4 text-sm text-slate-500">
        Free Gemini key Google AI Studio se milti hai:{" "}
        <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="font-bold text-violet-700 underline">
          aistudio.google.com/app/apikey
        </a>
        . Key paste karein. Key sirf is browser ki localStorage mein save hogi, code mein kuch nahi likha jata.
      </p>
      <div
        className={`mb-4 rounded-xl p-3 text-sm font-semibold ring-1 ${
          hasKey ? "bg-emerald-50 text-emerald-700 ring-emerald-200" : "bg-amber-50 text-amber-800 ring-amber-200"
        }`}
      >
        {hasKey ? "✅ Key saved hai. Story aur Essay AI se banenge." : "⚠️ Key nahi hai. Pre-written content use hoga."}
      </div>
      <div className="space-y-4">
        <Field label="Gemini API Key">
          <input
            type="password"
            className={`${inputCls} font-mono`}
            placeholder="AIza..."
            autoComplete="off"
            value={key}
            onChange={(e) => setKey(e.target.value)}
          />
        </Field>
        <div className="flex flex-col gap-3 sm:flex-row">
          <Btn
            onClick={() => {
              if (!key.trim()) return toast("Pehle key paste karein");
              saveSettings({ apiKey: key.trim() });
              setKey("");
              toast("API key saved");
            }}
          >
            💾 Save Key
          </Btn>
          {hasKey && (
            <Btn
              variant="danger"
              onClick={() => {
                saveSettings({ apiKey: "" });
                toast("API key removed");
              }}
            >
              Remove Key
            </Btn>
          )}
        </div>
      </div>
    </Card>
  );
}

function HistoryTab() {
  const history = useHistory();
  const sorted = [...history].sort((a, b) => (a.date < b.date ? 1 : -1));

  const remove = (id: string) => saveHistory(getHistory().filter((h) => h.id !== id));

  const clearAll = () => {
    if (!window.confirm("Sab users ki history delete ho jayegi. Pakka?")) return;
    saveHistory([]);
    toast("All history cleared");
  };

  return (
    <Card>
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-lg font-bold text-slate-900">Total History ({history.length})</h2>
        <Btn variant="danger" onClick={clearAll} disabled={history.length === 0}>
          🗑️ Clear All
        </Btn>
      </div>
      {sorted.length === 0 ? (
        <p className="py-6 text-center text-slate-600">Abhi koi history nahi hai.</p>
      ) : (
        <div className="space-y-3">
          {sorted.map((h) => (
            <div key={h.id} className="rounded-xl bg-slate-50 p-3 ring-1 ring-slate-200">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-sm font-bold text-slate-900">
                  {h.userName} <span className="font-normal text-slate-500">({h.userEmail})</span>
                </p>
                <button onClick={() => remove(h.id)} className="cursor-pointer text-xs font-bold text-red-600 hover:underline">
                  Delete
                </button>
              </div>
              <p className="text-xs text-slate-500">
                {h.tool} · {formatDate(h.date)}
              </p>
              <p className="mt-2 line-clamp-2 whitespace-pre-line text-sm text-slate-700">{h.result}</p>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}

function BackupTab() {
  return (
    <Card>
      <h2 className="mb-1 text-lg font-bold text-slate-900">Backup</h2>
      <p className="mb-5 text-sm text-slate-600">
        Sara data (users, history, settings, blog, stats) ek JSON file mein download karein. Ye file safe rakhein.
      </p>
      <Btn
        onClick={() => {
          downloadText(exportAllData(), `toolswala-backup-${todayKey()}.json`);
          toast("Backup downloaded");
        }}
      >
        💾 Download All Data
      </Btn>
    </Card>
  );
}
