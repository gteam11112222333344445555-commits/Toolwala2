// 5. Story Generator - real AI story if the admin added a Gemini key, else one of 30 pre-written stories.
import { useState } from "react";
import { Btn, Card, Field, inputCls } from "../components/ui";
import { STORY_TYPES, type StoryType } from "../lib/content";
import { askGemini } from "../lib/ai";
import { addHistory, useSettings } from "../lib/store";
import { copyText, downloadText, toast } from "../lib/helpers";
import { generateStory, storyTypeLabel } from "../lib/generators";

interface StoryResult {
  title: string;
  text: string;
  source: "AI" | "Pre-written";
}

export default function StoryTool() {
  const settings = useSettings();
  const [topic, setTopic] = useState("");
  const [type, setType] = useState<StoryType>("funny");
  const [story, setStory] = useState<StoryResult | null>(null);
  const [loading, setLoading] = useState(false);

  const preWritten = (t: string, s: StoryType): StoryResult => ({ ...generateStory(t, s), source: "Pre-written" });

  const run = async () => {
    const t = topic.trim();
    if (!t) return toast("Pehle topic likhein");
    setLoading(true);
    try {
      let result: StoryResult;
      if (settings.apiKey) {
        try {
          const raw = await askGemini(
            settings.apiKey,
            `Write a ${type} short story in simple English (about 200 to 250 words) about: "${t}". Put a title on the first line in the form "Title: your title", then leave one empty line and write the story. Keep it appropriate for all ages.`
          );
          const lines = raw.split("\n");
          const title = lines[0].replace(/^\**title:\s*/i, "").replace(/\*/g, "").trim() || `${t} Story`;
          const text = lines.slice(1).join("\n").trim() || raw;
          result = { title, text, source: "AI" };
        } catch (err) {
          toast(`AI error: ${(err as Error).message}. Pre-written story dikha rahe hain.`);
          result = preWritten(t, type);
        }
      } else {
        result = preWritten(t, type);
      }
      setStory(result);
      if (addHistory("story", `${result.title}\n\n${result.text}`)) toast("Story saved in History");
    } finally {
      setLoading(false);
    }
  };

  const fullText = story ? `${story.title}\n\n${story.text}` : "";

  return (
    <div className="space-y-5">
      <Card>
        <div className="space-y-5">
          <Field label="Topic">
            <input
              className={inputCls}
              placeholder="Jaise: Dog aur Cricket, Raat ka safar, Dost"
              maxLength={100}
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && run()}
            />
          </Field>
          <div className="space-y-2">
            <span className="text-sm font-semibold text-slate-700">Story Type</span>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {STORY_TYPES.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setType(s.id)}
                  className={`cursor-pointer rounded-xl px-3 py-3 text-sm font-semibold transition active:scale-95 ${
                    type === s.id
                      ? "bg-gradient-to-r from-violet-600 to-purple-700 text-white shadow-md"
                      : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                  }`}
                >
                  {s.icon} {s.label}
                </button>
              ))}
            </div>
          </div>
          <Btn onClick={run} disabled={loading} className="w-full sm:w-auto">
            📖 {loading ? "Likh raha hun..." : "Generate Story"}
          </Btn>
          <p className="text-xs text-slate-500">
            {settings.apiKey
              ? "✨ AI mode ON: Admin ki di gayi Gemini key use ho rahi hai."
              : "ℹ️ AI key nahi hai, isliye 30 pre-written stories mein se chuni jayegi."}
          </p>
        </div>
      </Card>

      {story && (
        <Card className="fade-in">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <span className="rounded-full bg-violet-100 px-3 py-1 text-xs font-bold text-violet-700">
              {STORY_TYPES.find((s) => s.id === type)?.icon} {storyTypeLabel(type)}
            </span>
            <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600">
              Source: {story.source}
            </span>
          </div>
          <h2 className="text-xl font-extrabold text-slate-900">{story.title}</h2>
          <p className="mt-4 whitespace-pre-line text-base leading-relaxed text-slate-700">{story.text}</p>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
            <Btn
              variant="secondary"
              onClick={async () => (await copyText(fullText)) && toast("Story copied!")}
            >
              📋 Copy Story
            </Btn>
            <Btn variant="secondary" onClick={() => downloadText(fullText, "toolswala-story.txt")}>
              ⬇️ Download Story
            </Btn>
            <Btn variant="success" onClick={run} disabled={loading}>
              🔄 Generate Again
            </Btn>
          </div>
        </Card>
      )}
    </div>
  );
}
