// 2. Meme Text Generator - upload your own photo or pick one of 6 ready memes.
import { useRef, useState } from "react";
import { Btn, Card, Field, inputCls } from "../components/ui";
import { MEMES } from "../lib/content";
import { addHistory } from "../lib/store";
import { canvasToBlob, copyText, downloadBlob, toast } from "../lib/helpers";

const SIZE = 1080;

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Image load failed"));
    img.src = src;
  });
}

function wrapLines(ctx: CanvasRenderingContext2D, text: string, maxW: number): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let cur = "";
  for (const w of words) {
    const test = cur ? `${cur} ${w}` : w;
    if (ctx.measureText(test).width <= maxW || !cur) {
      cur = test;
    } else {
      lines.push(cur);
      cur = w;
    }
  }
  if (cur) lines.push(cur);
  return lines;
}

function drawBlock(ctx: CanvasRenderingContext2D, text: string, where: "top" | "bottom") {
  const t = text.trim();
  if (!t) return;
  const maxW = SIZE * 0.92;
  const maxH = SIZE * 0.32;
  let size = 36;
  let lines: string[] = [];
  for (let s = 130; s >= 36; s -= 4) {
    ctx.font = `900 ${s}px Impact, "Arial Black", Arial, sans-serif`;
    const l = wrapLines(ctx, t.toUpperCase(), maxW);
    size = s;
    lines = l;
    if (l.length * s * 1.12 <= maxH) break;
  }
  const lh = size * 1.12;
  const blockH = lines.length * lh;
  let y = where === "top" ? 30 : SIZE - 30 - blockH;

  ctx.textAlign = "center";
  ctx.textBaseline = "top";
  ctx.lineJoin = "round";
  ctx.lineWidth = size / 7;
  ctx.strokeStyle = "#000";
  ctx.fillStyle = "#fff";
  for (const line of lines) {
    ctx.strokeText(line, SIZE / 2, y);
    ctx.fillText(line, SIZE / 2, y);
    y += lh;
  }
}

async function renderMeme(src: string, top: string, bottom: string): Promise<HTMLCanvasElement> {
  const img = await loadImage(src);
  const canvas = document.createElement("canvas");
  canvas.width = SIZE;
  canvas.height = SIZE;
  const ctx = canvas.getContext("2d")!;
  // cover-fit the photo into the square
  const r = Math.max(SIZE / img.width, SIZE / img.height);
  const w = img.width * r;
  const h = img.height * r;
  ctx.drawImage(img, (SIZE - w) / 2, (SIZE - h) / 2, w, h);
  drawBlock(ctx, top, "top");
  drawBlock(ctx, bottom, "bottom");
  return canvas;
}

export default function MemeTool() {
  const [src, setSrc] = useState<string | null>(null);
  const [topInput, setTopInput] = useState("");
  const [bottomInput, setBottomInput] = useState("");
  const [top, setTop] = useState("");
  const [bottom, setBottom] = useState("");
  const [made, setMade] = useState(false);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const onFile = (file?: File) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast("Sirf image file upload karein");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast("Photo 10MB se chhoti honi chahiye");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setSrc(String(reader.result));
      setMade(false);
      toast("Photo selected! Ab text likhein");
    };
    reader.readAsDataURL(file);
  };

  const pickReady = (s: string) => {
    setSrc(s);
    setMade(false);
  };

  const makeMeme = () => {
    if (!src) return toast("Pehle photo select karein");
    if (!topInput.trim() && !bottomInput.trim()) return toast("Top ya bottom text likhein");
    setTop(topInput.trim());
    setBottom(bottomInput.trim());
    setMade(true);
    const saved = addHistory("meme", `Top: ${topInput.trim() || "-"} | Bottom: ${bottomInput.trim() || "-"}`);
    toast(saved ? "Meme ready & saved in History" : "Meme ready!");
  };

  const download = async () => {
    if (!src) return toast("Pehle photo select karein");
    if (!made) return toast("Pehle 'Make Meme' dabayein");
    try {
      setBusy(true);
      const canvas = await renderMeme(src, top, bottom);
      downloadBlob(await canvasToBlob(canvas), "toolswala-meme.png");
      toast("Meme downloaded!");
    } catch {
      toast("Download failed, dusri photo try karein");
    } finally {
      setBusy(false);
    }
  };

  const copy = async () => {
    if (!made) return toast("Pehle 'Make Meme' dabayein");
    if (await copyText(`${top}\n${bottom}`.trim())) toast("Meme text copied!");
  };

  return (
    <div className="space-y-5">
      <Card>
        <h2 className="mb-3 text-lg font-bold text-slate-900">1. Photo chunein</h2>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="flex flex-col justify-center gap-3 rounded-2xl border-2 border-dashed border-violet-300 bg-violet-50/50 p-5 text-center">
            <div className="text-4xl">📸</div>
            <p className="text-sm text-slate-600">Apne mobile ya gallery se photo upload karein</p>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => onFile(e.target.files?.[0])}
            />
            <Btn variant="secondary" onClick={() => fileRef.current?.click()}>
              📁 Upload Photo
            </Btn>
          </div>

          <div>
            <p className="mb-2 text-sm font-semibold text-slate-700">Ya ready meme photo chunein:</p>
            <div className="grid grid-cols-3 gap-2">
              {MEMES.map((m) => (
                <button
                  key={m.src}
                  onClick={() => pickReady(m.src)}
                  aria-label={`Choose ${m.label}`}
                  className={`group relative aspect-square cursor-pointer overflow-hidden rounded-xl ring-2 transition active:scale-95 ${
                    src === m.src ? "ring-violet-600 ring-offset-2" : "ring-transparent hover:ring-violet-300"
                  }`}
                >
                  <img src={m.src} alt={m.label} className="h-full w-full object-cover" loading="lazy" />
                  <span className="absolute inset-x-0 bottom-0 bg-black/60 px-1 py-0.5 text-[10px] font-semibold text-white sm:text-xs">
                    {m.label}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </Card>

      <Card>
        <h2 className="mb-3 text-lg font-bold text-slate-900">2. Preview</h2>
        <div className="relative mx-auto aspect-square w-full max-w-md overflow-hidden rounded-2xl bg-slate-200 shadow-inner">
          {src ? (
            <>
              <img src={src} alt="Meme preview" className="h-full w-full object-cover" />
              <div className="meme-text absolute inset-x-0 top-3 break-words px-3 text-center text-2xl font-black uppercase leading-tight text-white sm:text-4xl">
                {top}
              </div>
              <div className="meme-text absolute inset-x-0 bottom-3 break-words px-3 text-center text-2xl font-black uppercase leading-tight text-white sm:text-4xl">
                {bottom}
              </div>
            </>
          ) : (
            <div className="flex h-full items-center justify-center p-6 text-center text-slate-500">
              Photo select karein taake meme yahan dikhe
            </div>
          )}
        </div>
      </Card>

      <Card>
        <h2 className="mb-3 text-lg font-bold text-slate-900">3. Text likhein</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Top Text">
            <input
              className={inputCls}
              maxLength={120}
              placeholder="Jaise: Jab exam ka pata chale"
              value={topInput}
              onChange={(e) => setTopInput(e.target.value)}
            />
          </Field>
          <Field label="Bottom Text">
            <input
              className={inputCls}
              maxLength={120}
              placeholder="Jaise: Aur sab so gaye"
              value={bottomInput}
              onChange={(e) => setBottomInput(e.target.value)}
            />
          </Field>
        </div>
        <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
          <Btn onClick={makeMeme} className="w-full sm:w-auto">
            ✨ Make Meme
          </Btn>
          <Btn variant="secondary" onClick={download} disabled={busy} className="w-full sm:w-auto">
            ⬇️ {busy ? "Preparing..." : "Download Meme"}
          </Btn>
          <Btn variant="secondary" onClick={copy} className="w-full sm:w-auto">
            📋 Copy Text
          </Btn>
        </div>
      </Card>
    </div>
  );
}
