// 3. Domain Name Generator - 20 name ideas with .com / .pk / .shop, Copy and Check buttons.
import { useState } from "react";
import { Btn, Card, Field, inputCls } from "../components/ui";
import { addHistory } from "../lib/store";
import { copyText, toast } from "../lib/helpers";
import { TLDS, buildDomainNames, sanitizeWord } from "../lib/generators";

export default function DomainTool() {
  const [word, setWord] = useState("");
  const [names, setNames] = useState<string[]>([]);
  const [tld, setTld] = useState<Record<string, string>>({});

  const generate = () => {
    const clean = sanitizeWord(word);
    if (!clean) return toast("Ek word likhein (sirf letters aur numbers)");
    const list = buildDomainNames(clean);
    setNames(list);
    setTld({});
    const summary = list.map((n) => `${n}: ${TLDS.map((t) => n.toLowerCase() + t).join(", ")}`).join("\n");
    if (addHistory("domain", summary)) toast("Names saved in History");
  };

  const fullDomain = (name: string) => `${name.toLowerCase()}${tld[name] ?? ".com"}`;

  const copyDomain = async (name: string) => {
    if (await copyText(fullDomain(name))) toast(`${fullDomain(name)} copied!`);
  };

  const checkDomain = (name: string) => {
    const url = `https://www.namecheap.com/domains/registration/results/?domain=${encodeURIComponent(
      fullDomain(name)
    )}`;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  return (
    <div className="space-y-5">
      <Card>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <div className="flex-1">
            <Field label="Ek word likhein">
              <input
                className={inputCls}
                placeholder="Jaise: Pizza"
                maxLength={30}
                value={word}
                onChange={(e) => setWord(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && generate()}
              />
            </Field>
          </div>
          <Btn onClick={generate} className="w-full sm:w-auto">
            🌐 Generate Names
          </Btn>
        </div>
      </Card>

      {names.length > 0 && (
        <Card>
          <h2 className="mb-1 text-lg font-bold text-slate-900">20 Domain Ideas</h2>
          <p className="mb-4 text-sm text-slate-500">
            Extension chunein (.com, .pk, .shop), phir Copy ya Check dabayein.
          </p>
          <ul className="grid gap-3 md:grid-cols-2">
            {names.map((name) => {
              const selected = tld[name] ?? ".com";
              return (
                <li
                  key={name}
                  className="fade-in flex flex-col gap-3 rounded-xl bg-slate-50 p-3 ring-1 ring-slate-200"
                >
                  <p className="min-w-0 break-all text-base font-extrabold text-slate-900">
                    {name}
                    <span className="text-violet-600">{selected}</span>
                  </p>
                  <div className="flex flex-wrap items-center gap-2">
                    {TLDS.map((t) => (
                      <button
                        key={t}
                        onClick={() => setTld({ ...tld, [name]: t })}
                        className={`cursor-pointer rounded-lg px-3 py-1 text-xs font-bold transition ${
                          selected === t
                            ? "bg-violet-600 text-white"
                            : "bg-white text-slate-600 ring-1 ring-slate-300 hover:bg-violet-50"
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                    <div className="ml-auto flex gap-2">
                      <Btn variant="secondary" className="!px-3 !py-1.5 text-xs" onClick={() => copyDomain(name)}>
                        📋 Copy
                      </Btn>
                      <Btn variant="success" className="!px-3 !py-1.5 text-xs" onClick={() => checkDomain(name)}>
                        🔍 Check
                      </Btn>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        </Card>
      )}
    </div>
  );
}
