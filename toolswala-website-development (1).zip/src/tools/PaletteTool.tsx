// 1. Color Palette Generator - no login needed. Click a box to copy its hex code.
import { useState } from "react";
import { Btn, Card } from "../components/ui";
import { addHistory } from "../lib/store";
import { canvasToBlob, copyText, downloadBlob, toast } from "../lib/helpers";
import { generatePalette } from "../lib/generators";

function renderPalette(colors: string[]): HTMLCanvasElement {
  const W = 1000;
  const H = 600;
  const labelH = 110;
  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d")!;
  const w = W / colors.length;

  colors.forEach((c, i) => {
    ctx.fillStyle = c;
    ctx.fillRect(i * w, 0, w, H - labelH);
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(i * w, H - labelH, w, labelH);
    ctx.fillStyle = "#0f172a";
    ctx.font = "bold 34px Arial, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(c, i * w + w / 2, H - labelH / 2);
  });
  return canvas;
}

export default function PaletteTool() {
  const [colors, setColors] = useState<string[]>(() => generatePalette());

  const generate = () => {
    const next = generatePalette();
    setColors(next);
    if (addHistory("palette", next.join(", "))) toast("Palette saved in History");
  };

  const copyOne = async (hex: string) => {
    if (await copyText(hex)) toast(`${hex} copied!`);
  };

  const copyAll = async () => {
    if (await copyText(colors.join(", "))) toast("All colors copied!");
    else toast("Copy failed, please try again");
  };

  const download = async () => {
    const blob = await canvasToBlob(renderPalette(colors));
    downloadBlob(blob, "toolswala-palette.png");
    toast("Palette image downloaded");
  };

  return (
    <div className="space-y-5">
      <Card>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-5 sm:gap-4">
          {colors.map((c, i) => (
            <button
              key={`${c}-${i}`}
              onClick={() => copyOne(c)}
              aria-label={`Copy color ${c}`}
              style={{ backgroundColor: c }}
              className="group relative flex h-20 cursor-pointer flex-row items-center justify-between rounded-2xl px-4 shadow-md ring-1 ring-black/5 transition hover:-translate-y-1 hover:shadow-xl active:scale-95 sm:h-80 sm:flex-col sm:justify-end sm:px-2 sm:pb-4"
            >
              <span className="rounded-lg bg-white/95 px-2.5 py-1 text-sm font-extrabold tracking-wide text-slate-900 shadow sm:text-base">
                {c}
              </span>
              <span className="rounded-md bg-black/40 px-2 py-0.5 text-xs font-semibold text-white opacity-100 transition sm:mt-2 sm:opacity-0 sm:group-hover:opacity-100">
                Tap to copy
              </span>
            </button>
          ))}
        </div>

        <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
          <Btn onClick={generate} className="w-full sm:w-auto">
            🎨 Generate Palette
          </Btn>
          <Btn variant="secondary" onClick={copyAll} className="w-full sm:w-auto">
            📋 Copy All
          </Btn>
          <Btn variant="secondary" onClick={download} className="w-full sm:w-auto">
            ⬇️ Download Palette as Image
          </Btn>
        </div>
      </Card>
      <p className="text-center text-sm text-slate-500">
        Color box par click karke hex code copy karein. Is tool ke liye login zaroori nahi hai.
      </p>
    </div>
  );
}
