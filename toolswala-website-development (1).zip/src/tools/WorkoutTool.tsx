// 4. Workout & Diet Plan - general 7-day plan (not medical advice).
import { useState } from "react";
import { jsPDF } from "jspdf";
import { Btn, Card, Field, inputCls } from "../components/ui";
import { GOALS, type Goal } from "../lib/content";
import { addHistory } from "../lib/store";
import { copyText, downloadText, toast } from "../lib/helpers";
import { buildPlan, planToText, type DayPlan } from "../lib/generators";

interface Result {
  plan: DayPlan[];
  text: string;
  goal: Goal;
  weight: number;
  age: number;
}

function downloadPdf(text: string) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  let y = 15;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.text("ToolsWala - 7 Day General Plan", 10, y);
  y += 10;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  for (const line of text.split("\n")) {
    const wrapped = doc.splitTextToSize(line || " ", 190) as string[];
    for (const w of wrapped) {
      if (y > 285) {
        doc.addPage();
        y = 15;
      }
      doc.text(w, 10, y);
      y += 5;
    }
  }
  doc.save("toolswala-workout-plan.pdf");
}

export default function WorkoutTool() {
  const [weight, setWeight] = useState("70");
  const [age, setAge] = useState("25");
  const [goal, setGoal] = useState<Goal>("fit");
  const [result, setResult] = useState<Result | null>(null);

  const generate = () => {
    const w = Number(weight);
    const a = Number(age);
    if (!(w >= 30 && w <= 250)) return toast("Weight 30 se 250 kg ke beech likhein");
    if (!(a >= 10 && a <= 90)) return toast("Age 10 se 90 ke beech likhein");
    const plan = buildPlan(a, goal);
    const text = planToText(plan, w, a, goal);
    setResult({ plan, text, goal, weight: w, age: a });
    if (addHistory("workout", text)) toast("Plan saved in History");
  };

  const goalInfo = GOALS.find((g) => g.id === goal);

  return (
    <div className="space-y-5">
      <Card>
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Weight (kg)">
            <input
              type="number"
              inputMode="numeric"
              className={inputCls}
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
            />
          </Field>
          <Field label="Age (saal)">
            <input
              type="number"
              inputMode="numeric"
              className={inputCls}
              value={age}
              onChange={(e) => setAge(e.target.value)}
            />
          </Field>
          <div className="space-y-1.5">
            <span className="text-sm font-semibold text-slate-700">Goal</span>
            <div className="grid grid-cols-1 gap-2">
              {GOALS.map((g) => (
                <button
                  key={g.id}
                  onClick={() => setGoal(g.id)}
                  className={`cursor-pointer rounded-xl px-3 py-2.5 text-sm font-semibold transition active:scale-95 ${
                    goal === g.id
                      ? "bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md"
                      : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                  }`}
                >
                  {g.label}
                </button>
              ))}
            </div>
          </div>
        </div>
        <p className="mt-4 rounded-xl bg-amber-50 p-3 text-xs text-amber-800 ring-1 ring-amber-200">
          ⚠️ Yeh sirf general plan hai, medical advice nahi. Kisi bhi health problem ke liye doctor se mashwara karein.
        </p>
        <Btn onClick={generate} className="mt-5 w-full sm:w-auto">
          💪 Generate 7-Day Plan
        </Btn>
      </Card>

      {result && (
        <>
          <Card className="fade-in">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h2 className="text-lg font-bold text-slate-900">Your 7-Day Plan</h2>
                <p className="text-sm text-slate-600">
                  Goal: <b>{goalInfo?.label}</b> · Weight: {result.weight} kg · Age: {result.age}
                </p>
                <p className="mt-1 text-xs text-emerald-700">💧 {goalInfo?.tip}</p>
              </div>
              <div className="flex flex-col gap-2 sm:flex-row">
                <Btn variant="secondary" onClick={async () => (await copyText(result.text)) && toast("Plan copied!")}>
                  📋 Copy Plan
                </Btn>
                <Btn variant="secondary" onClick={() => downloadPdf(result.text)}>
                  📄 Download PDF
                </Btn>
                <Btn variant="secondary" onClick={() => downloadText(result.text, "toolswala-workout-plan.txt")}>
                  📝 Download Text
                </Btn>
              </div>
            </div>
          </Card>

          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {result.plan.map((d) => (
              <div key={d.day} className="fade-in overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
                <div className="bg-gradient-to-r from-emerald-500 to-teal-600 px-4 py-2.5 font-bold text-white">
                  {d.day}
                </div>
                <div className="space-y-3 p-4 text-sm">
                  <div className="flex items-start gap-3 rounded-xl bg-emerald-50 p-3">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white text-2xl shadow">
                      {d.morning.icon}
                    </span>
                    <div>
                      <p className="text-xs font-bold uppercase text-emerald-700">Morning Exercise</p>
                      <p className="text-slate-800">{d.morning.text}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 rounded-xl bg-indigo-50 p-3">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white text-2xl shadow">
                      {d.evening.icon}
                    </span>
                    <div>
                      <p className="text-xs font-bold uppercase text-indigo-700">Evening Exercise</p>
                      <p className="text-slate-800">{d.evening.text}</p>
                    </div>
                  </div>
                  <ul className="space-y-2 text-slate-700">
                    <li>
                      <b>🍳 Breakfast:</b> {d.breakfast}
                    </li>
                    <li>
                      <b>🍛 Lunch:</b> {d.lunch}
                    </li>
                    <li>
                      <b>🥣 Dinner:</b> {d.dinner}
                    </li>
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
