// 6. Essay Generator - Heading, Introduction, Body, Conclusion. AI if key exists, else pre-written.
import { useState } from "react";
import { Btn, Card, Field, inputCls } from "../components/ui";
import { askGemini } from "../lib/ai";
import { addHistory, useSettings } from "../lib/store";
import { copyText, downloadText, toast } from "../lib/helpers";
import { generateEssay, type Essay } from "../lib/generators";

const CLASSES = [5, 6, 7, 8, 9, 10, 11, 12];
const WORD_OPTIONS = [200, 500, 1000];

interface EssayResult {
  essay?: Essay; // pre-written (structured)
  aiText?: string; // AI (plain text)
  heading: string;
  full: string;
  wordCount: number;
  source: "AI" | "Pre-written";
}

export default function EssayTool() {
  const settings = useSettings();
  const [topic, setTopic] = useState("");
  const [cls, setCls] = useState(7);
  const [words, setWords] = useState(200);
  const [result, setResult] = useState<EssayResult | null>(null);
  const [loading, setLoading] = useState(false);

  const run = async () => {
    const t = topic.trim();
    if (!t) return toast("Pehle topic likhein");
    setLoading(true);
    try {
      let res: EssayResult;
      if (settings.apiKey) {
        try {
          const text = await askGemini(
            settings.apiKey,
            `Write an essay on "${t}" for a Class ${cls} student. Length: about ${words} words. Use simple English suitable for Class ${cls}. Format it with these labels on their own lines: "Heading:", "Introduction:", "Body:", "Conclusion:". Do not use markdown symbols like ** or #.`
          );
          const plain = text.replace(/\*\*/g, "").replace(/^#+\s*/gm, "");
          res = {
            aiText: plain,
            heading: plain.split("\n")[0].replace(/^heading:\s*/i, "").trim() || `Essay on ${t}`,
            full: plain,
            wordCount: plain.split(/\s+/).filter(Boolean).length,
            source: "AI",
          };
        } catch (err) {
          toast(`AI error: ${(err as Error).message}. Pre-written essay dikha rahe hain.`);
          res = fromPreWritten(t);
        }
      } else {
        res = fromPreWritten(t);
      }
      setResult(res);
      if (addHistory("essay", res.full)) toast("Essay saved in History");
    } finally {
      setLoading(false);
    }
  };

  const fromPreWritten = (t: string): EssayResult => {
    const e = generateEssay(t, cls, words);
    return { essay: e, heading: e.heading, full: e.full, wordCount: e.wordCount, source: "Pre-written" };
  };

  return (
    <div className="space-y-5">
      <Card>
        <div className="space-y-5">
          <Field label="Topic">
            <input
              className={inputCls}
              placeholder="Jaise: My Favourite Teacher, Pollution, Importance of Education"
              maxLength={120}
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && run()}
            />
          </Field>

          <div className="space-y-2">
            <span className="text-sm font-semibold text-slate-700">Class</span>
            <div className="grid grid-cols-4 gap-2 sm:grid-cols-8">
              {CLASSES.map((c) => (
                <button
                  key={c}
                  onClick={() => setCls(c)}
                  className={`cursor-pointer rounded-xl py-2.5 text-sm font-bold transition active:scale-95 ${
                    cls === c
                      ? "bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-md"
                      : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                  }`}
                >
                  {c}th
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <span className="text-sm font-semibold text-slate-700">Words</span>
            <div className="grid grid-cols-3 gap-2">
              {WORD_OPTIONS.map((w) => (
                <button
                  key={w}
                  onClick={() => setWords(w)}
                  className={`cursor-pointer rounded-xl py-2.5 text-sm font-bold transition active:scale-95 ${
                    words === w
                      ? "bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-md"
                      : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                  }`}
                >
                  {w} words
                </button>
              ))}
            </div>
          </div>

          <Btn onClick={run} disabled={loading} className="w-full sm:w-auto">
            ✍️ {loading ? "Likh raha hun..." : "Generate Essay"}
          </Btn>
          <p className="text-xs text-slate-500">
            {settings.apiKey
              ? "✨ AI mode ON: Admin ki di gayi Gemini key use ho rahi hai."
              : "ℹ️ AI key nahi hai, isliye pre-written essay parts se essay banaya jayega."}
          </p>
        </div>
      </Card>

      {result && (
        <Card className="fade-in">
          <div className="mb-3 flex flex-wrap gap-2">
            <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-bold text-amber-800">
              Class {cls}
            </span>
            <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600">
              ~{result.wordCount} words
            </span>
            <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600">
              Source: {result.source}
            </span>
          </div>

          <h2 className="text-2xl font-extrabold text-slate-900">{result.heading}</h2>

          {result.essay ? (
            <div className="mt-4 space-y-5 text-base leading-relaxed text-slate-700">
              <section>
                <h3 className="mb-1 text-lg font-bold text-violet-700">Introduction</h3>
                <p>{result.essay.intro}</p>
              </section>
              <section>
                <h3 className="mb-1 text-lg font-bold text-violet-700">Body</h3>
                <div className="space-y-3">
                  {result.essay.body.map((p, i) => (
                    <p key={i}>{p}</p>
                  ))}
                </div>
              </section>
              <section>
                <h3 className="mb-1 text-lg font-bold text-violet-700">Conclusion</h3>
                <p>{result.essay.conclusion}</p>
              </section>
            </div>
          ) : (
            <p className="mt-4 whitespace-pre-line text-base leading-relaxed text-slate-700">{result.aiText}</p>
          )}

          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
            <Btn
              variant="secondary"
              onClick={async () => (await copyText(result.full)) && toast("Essay copied!")}
            >
              📋 Copy
            </Btn>
            <Btn variant="secondary" onClick={() => downloadText(result.full, "toolswala-essay.txt")}>
              ⬇️ Download
            </Btn>
            <Btn variant="success" onClick={run} disabled={loading}>
              🔄 Generate Again
            </Btn>
          </div>
        </Card>
      )}
    </div>
  );
}
