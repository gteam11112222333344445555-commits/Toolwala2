// Site footer with quick links and a small admin link.
import { Logo } from "./Logo";

export function Footer() {
  return (
    <footer className="mt-16 border-t border-slate-200 bg-white">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 py-8 text-center sm:flex-row sm:text-left">
        <Logo size="sm" />
        <p className="text-sm text-slate-500">© {new Date().getFullYear()} ToolsWala. 100% Free Tools.</p>
        <div className="flex gap-4 text-sm font-medium text-slate-600">
          <a href="#/" className="hover:text-violet-700">Home</a>
          <a href="#/tools" className="hover:text-violet-700">Tools</a>
          <a href="#/blog" className="hover:text-violet-700">Blog</a>
          <a href="#/admin" className="text-slate-400 hover:text-slate-700">Admin</a>
        </div>
      </div>
    </footer>
  );
}
