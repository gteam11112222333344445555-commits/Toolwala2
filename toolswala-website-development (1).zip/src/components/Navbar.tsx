// Top navigation: Home, Tools, Blog, Login. After login: user name, My History, Logout.
import { useState } from "react";
import { Logo } from "./Logo";
import { logout, useCurrentUser } from "../lib/store";
import { toast } from "../lib/helpers";

const LINKS = [
  { href: "#/", label: "Home", key: "" },
  { href: "#/tools", label: "Tools", key: "tools" },
  { href: "#/blog", label: "Blog", key: "blog" },
];

export function Navbar({ route }: { route: string }) {
  const [open, setOpen] = useState(false);
  const user = useCurrentUser();

  const doLogout = () => {
    logout();
    setOpen(false);
    toast("Logged out successfully");
    if (route === "history") window.location.hash = "#/";
  };

  const linkCls = (key: string) =>
    `rounded-lg px-3 py-2 text-sm font-semibold transition ${
      route === key ? "bg-violet-100 text-violet-700" : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
    }`;

  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
        <Logo />

        <nav className="hidden items-center gap-1 md:flex">
          {LINKS.map((l) => (
            <a key={l.label} href={l.href} className={linkCls(l.key)}>
              {l.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          {user ? (
            <>
              <span className="max-w-[140px] truncate rounded-full bg-violet-50 px-3 py-1.5 text-sm font-semibold text-violet-700">
                👋 {user.name}
              </span>
              <a href="#/history" className={linkCls("history")}>
                My History
              </a>
              <button
                onClick={doLogout}
                className="cursor-pointer rounded-xl bg-red-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-red-600 active:scale-95"
              >
                Logout
              </button>
            </>
          ) : (
            <a
              href="#/login"
              className="rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 px-5 py-2 text-sm font-semibold text-white shadow-md shadow-violet-200 transition hover:brightness-110 active:scale-95"
            >
              Login
            </a>
          )}
        </div>

        <button
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
          aria-expanded={open}
          className="inline-flex h-10 w-10 cursor-pointer items-center justify-center rounded-xl text-slate-700 hover:bg-slate-100 md:hidden"
        >
          {open ? (
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
              <path d="M6 6l12 12M18 6L6 18" />
            </svg>
          ) : (
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
              <path d="M4 7h16M4 12h16M4 17h16" />
            </svg>
          )}
        </button>
      </div>

      {open && (
        <div className="fade-in border-t border-slate-200 bg-white px-4 pb-4 md:hidden">
          <div className="flex flex-col gap-1 pt-2">
            {LINKS.map((l) => (
              <a key={l.label} href={l.href} onClick={() => setOpen(false)} className={linkCls(l.key) + " py-3"}>
                {l.label}
              </a>
            ))}
            {user ? (
              <>
                <div className="mt-2 rounded-xl bg-violet-50 px-3 py-3 text-sm font-semibold text-violet-700">
                  👋 {user.name}
                </div>
                <a href="#/history" onClick={() => setOpen(false)} className={linkCls("history") + " py-3"}>
                  My History
                </a>
                <button
                  onClick={doLogout}
                  className="mt-1 cursor-pointer rounded-xl bg-red-500 px-4 py-3 text-left text-sm font-semibold text-white"
                >
                  Logout
                </button>
              </>
            ) : (
              <a
                href="#/login"
                onClick={() => setOpen(false)}
                className="mt-2 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 px-4 py-3 text-center text-sm font-semibold text-white"
              >
                Login
              </a>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
