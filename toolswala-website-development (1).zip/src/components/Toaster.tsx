// Small toast message shown at the bottom of the screen.
import { useEffect, useState } from "react";

export function Toaster() {
  const [msg, setMsg] = useState<{ id: number; text: string } | null>(null);

  useEffect(() => {
    let timer: number | undefined;
    const handler = (e: Event) => {
      const text = (e as CustomEvent<string>).detail;
      setMsg({ id: Date.now(), text });
      window.clearTimeout(timer);
      timer = window.setTimeout(() => setMsg(null), 2200);
    };
    window.addEventListener("tw-toast", handler);
    return () => {
      window.removeEventListener("tw-toast", handler);
      window.clearTimeout(timer);
    };
  }, []);

  if (!msg) return null;
  return (
    <div
      key={msg.id}
      role="status"
      className="fade-in fixed bottom-5 left-1/2 z-50 max-w-[90vw] -translate-x-1/2 rounded-full bg-slate-900 px-5 py-2.5 text-center text-sm font-medium text-white shadow-xl"
    >
      {msg.text}
    </div>
  );
}
