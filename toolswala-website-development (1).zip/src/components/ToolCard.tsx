// Card shown on Home and Tools page: icon/photo, name, detail and "Use Tool" button.
import type { ToolDef } from "../lib/content";

export function ToolCard({ tool, enabled }: { tool: ToolDef; enabled: boolean }) {
  return (
    <div className="fade-in group flex flex-col overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 transition hover:-translate-y-1 hover:shadow-xl">
      <div
        className={`relative flex h-32 items-center justify-center bg-gradient-to-br ${tool.gradient}`}
      >
        <span className="text-6xl drop-shadow-lg transition group-hover:scale-110">{tool.icon}</span>
        {!enabled && (
          <span className="absolute right-3 top-3 rounded-full bg-black/60 px-3 py-1 text-xs font-bold text-white">
            Band hai
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col p-5">
        <h3 className="text-lg font-bold text-slate-900">{tool.name}</h3>
        <p className="mt-1 flex-1 text-sm leading-relaxed text-slate-600">{tool.detail}</p>
        {enabled ? (
          <a
            href={`#/tools/${tool.id}`}
            className="mt-4 inline-flex items-center justify-center rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 px-4 py-2.5 text-sm font-semibold text-white shadow-md shadow-violet-200 transition hover:brightness-110 active:scale-95"
          >
            Use Tool →
          </a>
        ) : (
          <span className="mt-4 inline-flex cursor-not-allowed items-center justify-center rounded-xl bg-slate-200 px-4 py-2.5 text-sm font-semibold text-slate-500">
            Abhi band hai
          </span>
        )}
      </div>
    </div>
  );
}
