// Logo: site name with the logo letter (default "W") shown inside a colorful box.
import { useSettings } from "../lib/store";

export function Logo({ size = "md", light = false }: { size?: "sm" | "md" | "lg"; light?: boolean }) {
  const s = useSettings();
  const letter = (s.logoLetter || "W").slice(0, 1);
  const name = s.siteName || "ToolsWala";
  const idx = name.indexOf(letter);

  const boxCls = {
    sm: "h-6 w-6 text-sm rounded-md",
    md: "h-8 w-8 text-lg rounded-lg",
    lg: "h-12 w-12 text-2xl rounded-xl",
  }[size];
  const textCls = {
    sm: "text-lg",
    md: "text-xl",
    lg: "text-3xl",
  }[size];
  const color = light ? "text-white" : "text-slate-900";

  const box = (
    <span
      className={`brand-box inline-flex shrink-0 items-center justify-center font-black text-white shadow-md ${boxCls}`}
    >
      {letter}
    </span>
  );

  return (
    <a href="#/" className={`inline-flex items-center font-extrabold tracking-tight ${textCls} ${color}`}>
      {idx >= 0 ? (
        <>
          <span>{name.slice(0, idx)}</span>
          <span className="mx-0.5">{box}</span>
          <span>{name.slice(idx + 1)}</span>
        </>
      ) : (
        <>
          {box}
          <span className="ml-2">{name}</span>
        </>
      )}
    </a>
  );
}
