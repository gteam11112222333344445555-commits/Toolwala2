// Ad slot. Shown only when the admin turns Ads ON. Admin can paste any ad HTML code (e.g. free AdSense snippet).
export function AdBox({ code }: { code: string }) {
  if (code.trim()) {
    return (
      <div className="mx-auto my-6 max-w-3xl overflow-hidden rounded-2xl bg-white p-2 text-center shadow-sm ring-1 ring-slate-200">
        <p className="mb-1 text-[10px] font-semibold uppercase tracking-widest text-slate-400">Advertisement</p>
        <div dangerouslySetInnerHTML={{ __html: code }} />
      </div>
    );
  }
  return (
    <div className="mx-auto my-6 flex max-w-3xl flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-300 bg-white p-6 text-center">
      <p className="text-xs font-semibold uppercase tracking-widest text-slate-400">Advertisement</p>
      <p className="mt-1 font-semibold text-slate-600">📢 Yahan aapka ad aayega</p>
      <p className="text-xs text-slate-400">Admin Panel → Ads mein ad code paste karein</p>
    </div>
  );
}
