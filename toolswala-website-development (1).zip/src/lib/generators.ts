// Generator logic for palette, domains, stories, essays and workout plans.
import { hslToHex } from "./helpers";
import {
  ESSAY_BODIES,
  ESSAY_CONCLUSIONS,
  ESSAY_EXAMPLES,
  ESSAY_INTROS,
  GOALS,
  STORIES,
  STORY_TYPES,
  WORKOUT_DATA,
  type Goal,
  type StoryType,
} from "./content";

export function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function titleCase(s: string): string {
  return s
    .trim()
    .replace(/\s+/g, " ")
    .split(" ")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(" ");
}

const fill = (text: string, topic: string) => text.split("{topic}").join(topic);

// ---------- PALETTE ----------

export function generatePalette(): string[] {
  const base = Math.floor(Math.random() * 360);
  const schemes = [
    [0, 30, 60, -30, -60], // analogous
    [0, 180, 30, 210, 150], // complementary mix
    [0, 120, 240, 60, 300], // triadic
  ];
  const offsets = pick(schemes);
  return offsets.map((o) => {
    const h = base + o;
    const s = 55 + Math.random() * 30;
    const l = 40 + Math.random() * 30;
    return hslToHex(h, s, l);
  });
}

// ---------- DOMAIN NAMES ----------

export const TLDS = [".com", ".pk", ".shop"];

const DOMAIN_PATTERNS: ((w: string) => string)[] = [
  (w) => `${w}Hub`,
  (w) => `${w}Pro`,
  (w) => `${w}World`,
  (w) => `Get${w}`,
  (w) => `Try${w}`,
  (w) => `${w}Zone`,
  (w) => `My${w}`,
  (w) => `${w}Now`,
  (w) => `${w}Expert`,
  (w) => `The${w}`,
  (w) => `${w}Shop`,
  (w) => `${w}Mart`,
  (w) => `${w}Club`,
  (w) => `Best${w}`,
  (w) => `${w}Online`,
  (w) => `${w}Store`,
  (w) => `${w}Plus`,
  (w) => `Go${w}`,
  (w) => `${w}Land`,
  (w) => `${w}Point`,
];

export function sanitizeWord(input: string): string {
  const clean = input.replace(/[^a-zA-Z0-9]/g, "");
  return clean.charAt(0).toUpperCase() + clean.slice(1).toLowerCase();
}

export function buildDomainNames(word: string): string[] {
  return DOMAIN_PATTERNS.map((p) => p(word));
}

// ---------- STORY ----------

export function storyTypeLabel(type: StoryType): string {
  return STORY_TYPES.find((t) => t.id === type)?.label ?? type;
}

export function generateStory(topic: string, type: StoryType): { title: string; text: string } {
  const t = topic.trim();
  const pool = STORIES.filter((s) => s.type === type);
  const story = pick(pool);
  return {
    title: `${titleCase(t)}: A ${storyTypeLabel(type)} Story`,
    text: fill(story.text, t),
  };
}

// ---------- ESSAY ----------

export interface Essay {
  heading: string;
  intro: string;
  body: string[];
  conclusion: string;
  full: string;
  wordCount: number;
}

export function generateEssay(topic: string, cls: number, words: number): Essay {
  const t = topic.trim();
  const bodyCount = words <= 200 ? 3 : words <= 500 ? 8 : 12;
  const exampleCount = words <= 200 ? 0 : words <= 500 ? 2 : 12;

  const intro = `${fill(pick(ESSAY_INTROS), t)} As a student of Class ${cls}, I think this topic is worth understanding well.`;
  const bodyTexts = shuffle(ESSAY_BODIES)
    .slice(0, bodyCount)
    .map((p) => fill(p, t));
  const examples = shuffle(ESSAY_EXAMPLES)
    .slice(0, exampleCount)
    .map((p) => fill(p, t));
  const body = bodyTexts.map((b, i) => (examples[i] ? `${b} ${examples[i]}` : b));
  const conclusion = fill(pick(ESSAY_CONCLUSIONS), t);
  const heading = `Essay on ${titleCase(t)}`;

  const full = [
    heading,
    "Introduction",
    intro,
    "Body",
    ...body,
    "Conclusion",
    conclusion,
  ].join("\n\n");

  const wordCount = full.split(/\s+/).filter(Boolean).length;
  return { heading, intro, body, conclusion, full, wordCount };
}

// ---------- WORKOUT & DIET ----------

export interface DayPlan {
  day: string;
  morning: { icon: string; text: string };
  evening: { icon: string; text: string };
  breakfast: string;
  lunch: string;
  dinner: string;
}

export const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

export function buildPlan(age: number, goal: Goal): DayPlan[] {
  const pickIdx = (arr: string[], i: number) => arr[(i + Math.floor(age / 10)) % arr.length];
  return DAYS.map((day, i) => {
    const isSunday = i === 6;
    const morningList = WORKOUT_DATA.morning[goal];
    const eveningList = WORKOUT_DATA.evening[goal];
    return {
      day,
      morning: isSunday
        ? { icon: "🧘", text: "Rest day - light walk 15 minutes and stretching" }
        : morningList[i % morningList.length],
      evening: isSunday
        ? { icon: "😴", text: "Full rest - aim for 7 to 8 hours of sleep" }
        : eveningList[i % eveningList.length],
      breakfast: pickIdx(WORKOUT_DATA.breakfast[goal], i),
      lunch: pickIdx(WORKOUT_DATA.lunch[goal], i),
      dinner: pickIdx(WORKOUT_DATA.dinner[goal], i),
    };
  });
}

export function planToText(plan: DayPlan[], weight: number, age: number, goal: Goal): string {
  const goalLabel = GOALS.find((g) => g.id === goal)?.label ?? goal;
  const water = (weight * 0.035).toFixed(1);
  const header = [
    "ToolsWala - 7 Day General Plan",
    `Weight: ${weight} kg | Age: ${age} | Goal: ${goalLabel}`,
    `Water (general guide): about ${water} litres per day`,
    `Tip: ${GOALS.find((g) => g.id === goal)?.tip ?? ""}`,
    age >= 40 ? "Note: After 40, keep exercise light and always warm up first." : "",
    "Disclaimer: This is a general plan, not medical advice. Consult a doctor for any health issue.",
    "",
  ]
    .filter((l) => l !== "")
    .join("\n");

  const days = plan
    .map(
      (d) =>
        `${d.day}\n` +
        `  Morning Exercise: ${d.morning.text}\n` +
        `  Evening Exercise: ${d.evening.text}\n` +
        `  Breakfast: ${d.breakfast}\n` +
        `  Lunch: ${d.lunch}\n` +
        `  Dinner: ${d.dinner}`
    )
    .join("\n\n");

  return `${header}\n${days}`;
}
