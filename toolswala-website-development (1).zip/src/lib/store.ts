// Local storage layer: users, session, history, settings, blog, usage stats and visitors.
// Everything lives in the browser's localStorage (100% free, no backend).
import { useEffect, useState } from "react";
import { uid } from "./helpers";

export type ToolId = "palette" | "meme" | "domain" | "workout" | "story" | "essay";

export interface User {
  name: string;
  email: string;
  password: string;
  blocked: boolean;
  createdAt: string;
}

export interface HistoryItem {
  id: string;
  userEmail: string;
  userName: string;
  date: string;
  tool: ToolId;
  result: string;
}

export interface BlogPost {
  id: string;
  title: string;
  body: string;
  date: string;
}

export interface Settings {
  siteName: string;
  logoLetter: string;
  heroText: string;
  adsOn: boolean;
  adCode: string;
  apiKey: string;
  tools: Record<ToolId, boolean>;
}

// Admin login (as requested). The Gemini API key is NOT stored in code.
export const ADMIN_EMAIL = "admin@toolswala.com";
export const ADMIN_PASSWORD = "admin123";

export const KEYS = {
  users: "tw_users",
  session: "tw_session",
  admin: "tw_admin_session",
  history: "tw_history",
  settings: "tw_settings",
  blog: "tw_blog",
  usage: "tw_usage",
  visits: "tw_visits",
} as const;

export const DEFAULT_TOOLS: Record<ToolId, boolean> = {
  palette: true,
  meme: true,
  domain: true,
  workout: true,
  story: true,
  essay: true,
};

export const DEFAULT_SETTINGS: Settings = {
  siteName: "ToolsWala",
  logoLetter: "W",
  heroText:
    "Color palette, meme maker, domain names, workout & diet plan, story aur essay, sab kuch ek jagah. 100% free, mobile par bhi chalta hai.",
  adsOn: false,
  adCode: "",
  apiKey: "",
  tools: DEFAULT_TOOLS,
};

export const DEFAULT_BLOG: BlogPost[] = [
  {
    id: "seed1",
    title: "Welcome to ToolsWala",
    body: "ToolsWala par aap free tools use kar sakte hain: color palette, meme maker, domain names, workout plan, story aur essay. Login karke apni history save karein.",
    date: "2026-01-01T10:00:00.000Z",
  },
  {
    id: "seed2",
    title: "Tips for Better Study Essays",
    body: "Essay likhne se pehle topic ko samjhein, phir introduction, body aur conclusion ka plan banayein. Simple language aur clear examples se essay better banta hai.",
    date: "2026-01-05T10:00:00.000Z",
  },
];

// ---------- generic read / write ----------

export function read<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    return raw === null ? fallback : (JSON.parse(raw) as T);
  } catch {
    return fallback;
  }
}

export function write<T>(key: string, value: T) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage full - ignore */
  }
  window.dispatchEvent(new Event("tw-update"));
}

// React hook that re-renders whenever the stored value changes.
export function useStored<T>(key: string, fallback: T): T {
  const [value, setValue] = useState<T>(() => read(key, fallback));
  useEffect(() => {
    const refresh = () => setValue(read(key, fallback));
    window.addEventListener("tw-update", refresh);
    return () => window.removeEventListener("tw-update", refresh);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  return value;
}

// ---------- settings ----------

function mergeSettings(s: Partial<Settings> | null | undefined): Settings {
  const src = s ?? {};
  return {
    ...DEFAULT_SETTINGS,
    ...src,
    tools: { ...DEFAULT_TOOLS, ...(src.tools ?? {}) },
  };
}

export function getSettings(): Settings {
  return mergeSettings(read<Partial<Settings>>(KEYS.settings, {}));
}

export function useSettings(): Settings {
  const raw = useStored<Partial<Settings>>(KEYS.settings, {});
  return mergeSettings(raw);
}

export function saveSettings(patch: Partial<Settings>) {
  const current = getSettings();
  write(KEYS.settings, {
    ...current,
    ...patch,
    tools: { ...current.tools, ...(patch.tools ?? {}) },
  });
}

// ---------- users & session ----------

export function getUsers(): User[] {
  return read<User[]>(KEYS.users, []);
}

export function saveUsers(users: User[]) {
  write(KEYS.users, users);
}

export function useUsers(): User[] {
  return useStored<User[]>(KEYS.users, []);
}

export function getSessionEmail(): string | null {
  return read<string | null>(KEYS.session, null);
}

export function getCurrentUser(): User | null {
  const email = getSessionEmail();
  if (!email) return null;
  const u = getUsers().find((x) => x.email === email);
  return u && !u.blocked ? u : null;
}

export function useCurrentUser(): User | null {
  const users = useUsers();
  const email = useStored<string | null>(KEYS.session, null);
  const u = users.find((x) => x.email === email);
  return u && !u.blocked ? u : null;
}

export function signup(name: string, email: string, password: string): string | null {
  const e = email.trim().toLowerCase();
  if (!name.trim()) return "Please enter your name.";
  if (!/^\S+@\S+\.\S+$/.test(e)) return "Please enter a valid email.";
  if (password.length < 6) return "Password must be at least 6 characters.";
  if (e === ADMIN_EMAIL) return "This email is reserved.";
  const users = getUsers();
  if (users.some((u) => u.email === e)) return "An account with this email already exists.";
  users.push({
    name: name.trim(),
    email: e,
    password,
    blocked: false,
    createdAt: new Date().toISOString(),
  });
  saveUsers(users);
  write(KEYS.session, e);
  return null;
}

export function login(email: string, password: string): string | null {
  const e = email.trim().toLowerCase();
  const u = getUsers().find((x) => x.email === e);
  if (!u || u.password !== password) return "Email or password is wrong.";
  if (u.blocked) return "Your account has been blocked by admin.";
  write(KEYS.session, e);
  return null;
}

export function logout() {
  write(KEYS.session, null);
}

export function resetPassword(email: string, newPassword: string): string | null {
  const e = email.trim().toLowerCase();
  if (newPassword.length < 6) return "New password must be at least 6 characters.";
  const users = getUsers();
  const u = users.find((x) => x.email === e);
  if (!u) return "No account found with this email.";
  saveUsers(users.map((x) => (x.email === e ? { ...x, password: newPassword } : x)));
  return null;
}

// ---------- admin session ----------

export function useIsAdmin(): boolean {
  return useStored<boolean>(KEYS.admin, false);
}

export function setAdmin(on: boolean) {
  write(KEYS.admin, on);
}

// ---------- history ----------

export function getHistory(): HistoryItem[] {
  return read<HistoryItem[]>(KEYS.history, []);
}

export function saveHistory(list: HistoryItem[]) {
  write(KEYS.history, list);
}

export function useHistory(): HistoryItem[] {
  return useStored<HistoryItem[]>(KEYS.history, []);
}

// Saves a tool result when a user is logged in. Always counts the tool usage.
export function addHistory(tool: ToolId, result: string): boolean {
  bumpUsage(tool);
  const u = getCurrentUser();
  if (!u) return false;
  const item: HistoryItem = {
    id: uid(),
    userEmail: u.email,
    userName: u.name,
    date: new Date().toISOString(),
    tool,
    result,
  };
  saveHistory([item, ...getHistory()].slice(0, 100));
  return true;
}

// ---------- usage & visitors ----------

export function todayKey(): string {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

export function bumpUsage(tool: ToolId) {
  const usage = read<Record<string, number>>(KEYS.usage, {});
  usage[tool] = (usage[tool] ?? 0) + 1;
  write(KEYS.usage, usage);
}

export function useUsage(): Record<string, number> {
  return useStored<Record<string, number>>(KEYS.usage, {});
}

export function trackVisit() {
  if (sessionStorage.getItem("tw_visited")) return;
  sessionStorage.setItem("tw_visited", "1");
  const visits = read<Record<string, number>>(KEYS.visits, {});
  const key = todayKey();
  visits[key] = (visits[key] ?? 0) + 1;
  write(KEYS.visits, visits);
}

export function useVisits(): Record<string, number> {
  return useStored<Record<string, number>>(KEYS.visits, {});
}

// ---------- blog ----------

export function getBlog(): BlogPost[] {
  return read<BlogPost[]>(KEYS.blog, DEFAULT_BLOG);
}

export function saveBlog(list: BlogPost[]) {
  write(KEYS.blog, list);
}

export function useBlog(): BlogPost[] {
  return useStored<BlogPost[]>(KEYS.blog, DEFAULT_BLOG);
}

// ---------- backup ----------

export function exportAllData(): string {
  const data: Record<string, unknown> = {};
  Object.entries(KEYS).forEach(([name, key]) => {
    data[name] = read(key, null);
  });
  return JSON.stringify(
    { site: "ToolsWala", exportedAt: new Date().toISOString(), data },
    null,
    2
  );
}
