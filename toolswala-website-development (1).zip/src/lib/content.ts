// All pre-written content: tool list, memes, 30 stories, essay parts, workout & diet data.
import type { ToolId } from "./store";

export const asset = (path: string) => `${import.meta.env.BASE_URL}${path}`;

export interface ToolDef {
  id: ToolId;
  name: string;
  icon: string;
  detail: string;
  gradient: string;
}

export const TOOLS: ToolDef[] = [
  {
    id: "palette",
    name: "Color Palette Generator",
    icon: "🎨",
    detail: "Ek click mein 5 khoobsurat colors, hex codes ke saath. Copy karein ya image download karein.",
    gradient: "from-pink-500 to-orange-400",
  },
  {
    id: "meme",
    name: "Meme Text Generator",
    icon: "😂",
    detail: "Apni photo upload karein ya 6 ready memes chunein, top aur bottom text likhein.",
    gradient: "from-yellow-400 to-red-500",
  },
  {
    id: "domain",
    name: "Domain Name Generator",
    icon: "🌐",
    detail: "Ek word likhein, 20 domain names paayein (.com, .pk, .shop) aur check karein.",
    gradient: "from-cyan-500 to-blue-600",
  },
  {
    id: "workout",
    name: "Workout & Diet Plan",
    icon: "🏋️",
    detail: "Weight, age aur goal ke hisaab se 7-din ka general exercise aur khana plan.",
    gradient: "from-emerald-500 to-teal-600",
  },
  {
    id: "story",
    name: "Story Generator",
    icon: "📖",
    detail: "Topic aur type (Funny, Horror, Love, Moral) chunein, kahani turant tayyar.",
    gradient: "from-violet-500 to-purple-700",
  },
  {
    id: "essay",
    name: "Essay Generator",
    icon: "✍️",
    detail: "Class 5 se 12 ke liye Heading, Introduction, Body aur Conclusion wala essay.",
    gradient: "from-amber-500 to-orange-600",
  },
];

export const MEMES = [
  { src: asset("memes/meme1.jpg"), label: "Shocked Cat" },
  { src: asset("memes/meme2.jpg"), label: "Confused Dog" },
  { src: asset("memes/meme3.jpg"), label: "Sleepy Panda" },
  { src: asset("memes/meme4.jpg"), label: "Dancing Chicken" },
  { src: asset("memes/meme5.jpg"), label: "Jumping Frog" },
  { src: asset("memes/meme6.jpg"), label: "Cool Penguin" },
];

// ---------- STORIES (30 pre-written, {topic} is replaced by user topic) ----------

export type StoryType = "funny" | "horror" | "love" | "moral";

export const STORY_TYPES: { id: StoryType; label: string; icon: string }[] = [
  { id: "funny", label: "Funny", icon: "😂" },
  { id: "horror", label: "Horror", icon: "👻" },
  { id: "love", label: "Love", icon: "💖" },
  { id: "moral", label: "Moral", icon: "🌟" },
];

export const STORIES: { type: StoryType; text: string }[] = [
  // Funny (8)
  { type: "funny", text: "Once there was a cat who loved {topic} more than anything. One day it tried to catch a fish from the fish tank and fell in headfirst. The fish looked at the cat and said, 'You should stick to milk!' The cat sneezed, shook off the water, and promised never to bother the fish again." },
  { type: "funny", text: "Ahmed had a big exam about {topic}. He studied all night and wrote every answer on his hand. In the morning he washed his hands with lots of soap. When the teacher asked a question, Ahmed looked at his palm, but it was blank. He smiled and said, 'Sir, I forgot to read my own hand!'" },
  { type: "funny", text: "Grandma decided to learn {topic} from her smartphone. She tapped the screen so hard that the phone started playing music, opened the camera, and called her neighbour by mistake. The neighbour answered, 'Hello? Grandma, are you dancing again?' Grandma laughed and said, 'Yes beta, the phone is teaching me!'" },
  { type: "funny", text: "A little robot named Bolt was asked to make tea for guests. It was so excited about {topic} that it added sugar, salt, chilli, and one sock. The guests tasted it, made a face, and then laughed so hard they forgot they were thirsty. Bolt learned that some recipes are better left to humans." },
  { type: "funny", text: "Sara wanted to win the {topic} competition. She practised for weeks, wore her lucky hat, and walked on stage with confidence. Then her hat fell off, bounced on the floor, and rolled straight into the judge's soup. The judge looked at the hat, then at Sara, and gave her the prize for 'Most Entertaining Performance'." },
  { type: "funny", text: "Uncle Bilal bought a new bicycle for {topic} practice. He rode it proudly down the street, but he had forgotten how brakes work. He crashed gently into a fruit cart, and oranges rolled everywhere. The fruit seller smiled, 'Sir, now you have made a juice shop!' Uncle Bilal paid for the oranges and walked his bicycle home." },
  { type: "funny", text: "The school bell rang for {topic} class, but the monkey in the back row did not move. The teacher asked him to answer. The monkey picked up a banana, peeled it, and started eating. 'Correct answer,' said the teacher, 'but please bring your own chair next time!' The whole class laughed until the bell rang again." },
  { type: "funny", text: "A shy goat wanted to join the {topic} team. On the first day it kept saying 'Meh' instead of hello. The coach was confused until a little bird explained, 'It means I am ready!' From that day the goat became the team's loudest cheerleader, and everyone learned that the goat was never really shy." },
  // Horror (8)
  { type: "horror", text: "Every night at midnight, the old house on the hill near {topic} made a soft knocking sound. Zain decided to find out why. He climbed the creaky stairs, opened the attic door, and saw a small wooden box. Inside was a note: 'Thank you for listening. Please close the door behind you.' Zain turned around, but the door was already closed." },
  { type: "horror", text: "The villagers warned everyone not to go near the lake after sunset, especially on {topic} nights. Hina did not believe the stories. As she walked by the water, she heard a voice calling her name from the deep. She looked down and saw her own reflection smiling, even though she was not smiling at all. She ran home and never looked at water again." },
  { type: "horror", text: "In a quiet town, a clock in the square stopped at 3:33 every night. People said it was cursed by a {topic} collector who vanished long ago. One night a boy named Omar stayed awake to watch. At 3:33 the clock struck thirteen times, and a cold whisper said, 'Now it is your turn to keep time.'" },
  { type: "horror", text: "Sana's new phone had an app about {topic}. Every night it showed a photo of her bedroom, taken from the corner of the ceiling. One night the photo had a new shadow standing beside her bed. Sana turned slowly, but the room was empty. The next morning the app showed a new photo: the shadow was now sitting on her bed." },
  { type: "horror", text: "The forest behind the school was famous for its {topic} legends. Three friends went there to prove they were fake. They lit a fire and told stories. Then one friend counted the group and said, 'Four.' Nobody had brought a fourth friend. They turned around and saw a pale figure smiling between the trees." },
  { type: "horror", text: "The painting in Grandpa's hallway always showed a happy family. But one day a new face appeared in the corner, a girl with dark eyes holding a {topic} doll. Every day she came a little closer to the edge of the frame. When she finally reached the front door of the painting, the house fell silent forever." },
  { type: "horror", text: "Hamza lived near an abandoned train station. Every evening a train whistle sounded, though no train ever came. One night he followed the sound onto the tracks. A conductor in an old uniform stood there, holding a ticket with Hamza's name on it. 'Your {topic} journey starts now,' he said, and all the lights went out." },
  { type: "horror", text: "The school library had a book that no one could borrow. It was about {topic}, and its pages were always warm. When Ayesha finally opened it, every page showed a picture of her sleeping in the library. On the last page a tiny message said: 'Please wake up before the library closes.' Ayesha woke up screaming." },
  // Love (7)
  { type: "love", text: "Maria and Usman met every morning at the same bus stop. They talked about {topic}, music, and their favourite foods. One rainy day Usman forgot his umbrella, and Maria shared hers. Under that small umbrella they discovered that the bus stop had become their favourite place in the world." },
  { type: "love", text: "Ali wrote a letter every week to his best friend Noor. Each letter was about {topic}, a dream, or a memory. Noor kept every letter in a wooden box. Years later, when Ali finally asked her to marry him, she opened the box and said, 'I have been waiting for your next letter.'" },
  { type: "love", text: "Zara loved painting sunsets. Her neighbour Imran loved fixing old bicycles. One day Zara painted a bicycle inside her sunset picture, and Imran painted a sunset on his bicycle wheel. They laughed and realised their hearts were painted in the same colours. Their story of {topic} began right there." },
  { type: "love", text: "Two strangers sat on the same train every evening. He always read a book, she always drew pictures. One day a page fell from her sketchbook. It was a drawing of him, reading by the window. He smiled and said, 'Now I know what your {topic} looks like.' They got off at the same station that day." },
  { type: "love", text: "Hira planted a rose in her garden the day she moved in. Her neighbour Faisal watered it every morning without saying a word. When the rose finally bloomed, Hira found a note under the pot: 'Some {topic} grow slowly, but they grow the most beautiful when they are cared for together.'" },
  { type: "love", text: "During the flood, Bilal carried a small boat across the river to reach Sadia. He did not ask for anything in return. Sadia held his hand and said, 'You are the bravest person I know.' In that moment the river was no longer a barrier. It became the place where their {topic} story began." },
  { type: "love", text: "Every Eid, Farhan sent Sana a small box of sweets with a poem inside. This year the box was late, and Sana started to worry. Then she heard a knock. Farhan stood at the door, covered in flour, holding a cake shaped like a heart. 'I tried to learn {topic} for you,' he said. She laughed and hugged him." },
  // Moral (7)
  { type: "moral", text: "A greedy fox found a basket of grapes in a farmer's field. He ate them all and ran away. The next day he was hungry again and found nothing. He learned that taking more than you need brings sorrow. Sharing what you have, like the tree shares its shade with {topic} lovers, brings true happiness." },
  { type: "moral", text: "Two brothers fought over a toy until it broke. Their mother sat them down and said, 'When you work together, you can fix anything.' They built a new toy from the broken pieces. This taught them that {topic} is better when shared, and that teamwork turns problems into gifts." },
  { type: "moral", text: "A young boy told the village every day that a wolf was coming, just for fun. When a real wolf came, nobody believed him. The boy learned that honesty is the strongest thing a person can own. Truth is like {topic}: it protects you when you need it most." },
  { type: "moral", text: "Ayaan saw an old man struggling with heavy bags and did not help, because he was in a hurry. Later he needed help himself, and nobody stopped. He understood that kindness works like a boomerang. Every small act of {topic} and goodness returns to us one day." },
  { type: "moral", text: "The ant worked all summer collecting food while the grasshopper sang and played. When winter came, the grasshopper had nothing. The ant shared a little food, and the grasshopper promised to work harder next year. The story teaches us that planning and hard work matter in every part of life, including {topic}." },
  { type: "moral", text: "A rich man refused to give anything to the poor because he thought wealth would last forever. One night a storm carried away his fortune. He realised that money is not everything. Helping others with {topic} and kindness is what makes a life truly valuable." },
  { type: "moral", text: "A girl named Fatima always said 'Thank you' to everyone. Her teacher, her neighbours, and even the shopkeeper smiled at her. One day she learned that a simple thank you can make someone's whole day better. Good manners and gratitude about {topic} make the world a warmer place." },
];

// ---------- ESSAY PARTS (pre-written; {topic} is replaced) ----------

export const ESSAY_INTROS: string[] = [
  "{topic} is one of the most important topics in our daily life. Every person, young or old, comes across it in some way.",
  "Today we are going to talk about {topic}. It plays a big role in shaping our society, our habits, and our future.",
  "When we think about {topic}, we realise how much it affects us. From school to home, it touches almost every part of our lives.",
  "Many people often ignore {topic}, but it deserves our attention. Understanding it well can make us better students and better citizens.",
  "{topic} has been discussed by thinkers and teachers for many years. Its value is still clear in the modern world.",
  "If we look around carefully, we can see {topic} everywhere. It is simple to notice, yet deep in meaning.",
  "In this essay I will explain what {topic} means, why it matters, and how we can make the most of it.",
  "Imagine a world without {topic}. It would be very different and much harder for everyone to live in.",
  "{topic} is not just a word; it is a part of our everyday experience. Let us understand its importance together.",
  "Growing up, I learned that {topic} can change the way we think and act. That is why it is worth discussing.",
];

export const ESSAY_BODIES: string[] = [
  "The first point to understand is that {topic} teaches us discipline. When we make a plan and follow it step by step, we learn patience and responsibility. These qualities help us in school, at work, and in our personal relationships.",
  "Another important aspect of {topic} is its effect on families. Parents, children, and grandparents all benefit when they share respect and care. A happy home is often built on small acts of understanding.",
  "{topic} also plays a role in education. Students who understand it well can think more clearly, solve problems faster, and express their ideas with confidence. Teachers often use it to inspire curiosity in the classroom.",
  "In the community, {topic} brings people together. When neighbours help one another and share ideas, the whole area becomes stronger. Small projects, like cleaning a street or organising a fair, show the power of collective effort.",
  "Health is another area where {topic} matters. A balanced routine, enough rest, and regular activity keep both body and mind fit. Many problems can be prevented when we pay attention to these simple habits.",
  "The economic side of {topic} should not be forgotten either. When people use their time and resources wisely, they create opportunities for themselves and for others. Smart choices today lead to a better tomorrow.",
  "Technology has changed the way we experience {topic}. Information is now available at our fingertips, but we must use it carefully. Checking facts and thinking critically help us benefit from modern tools without being misled.",
  "Nature and the environment are closely linked with {topic}. Protecting trees, saving water, and reducing waste are practical steps. Each person can contribute, even with small daily actions.",
  "Moral values are at the heart of {topic}. Honesty, kindness, and respect make our actions meaningful. When we treat others fairly we build trust, and trust is the foundation of every strong relationship.",
  "Challenges are part of {topic} too. Sometimes we face failure or confusion. But every difficulty teaches a lesson, and those who keep trying usually find a way forward with courage and hard work.",
  "Creativity also has a place in {topic}. New ideas, art, and imagination can give a fresh view of old problems. Encouraging young people to think creatively helps them become confident and original thinkers.",
  "Finally, {topic} connects us with the wider world. By learning about other cultures and experiences, we develop tolerance and understanding. This makes us more open-minded and helps us contribute to peace and progress.",
];

export const ESSAY_EXAMPLES: string[] = [
  "For example, a student who practises {topic} every day usually finds that their confidence grows over time.",
  "A good example can be seen in my own school, where a small group started working on {topic} and inspired the whole class.",
  "Many successful people say that {topic} was the key to their achievements, because they never gave up on their goals.",
  "In our neighbourhood, a simple project related to {topic} brought families together for a weekend of fun and learning.",
  "History shows us many examples where {topic} helped communities overcome difficult times and build something lasting.",
  "Even a small change, like spending ten minutes a day on {topic}, can produce surprising results after a few months.",
  "Teachers often share stories of students who discovered their talent through {topic} and later became leaders in their fields.",
  "When families talk openly about {topic}, children learn to listen, ask questions, and make better decisions for themselves.",
  "Newspapers and television often highlight how {topic} can solve real problems in villages and cities alike.",
  "Friends who support each other in {topic} tend to stay motivated, and this teamwork makes every task feel lighter.",
  "Consider a farmer who used {topic} wisely; his hard work improved his harvest and helped feed many families nearby.",
  "In the end, the lesson of {topic} is visible in everyday choices, such as how we speak, how we study, and how we treat others.",
];

export const ESSAY_CONCLUSIONS: string[] = [
  "In conclusion, {topic} is a valuable part of our life. If we understand it, respect it, and practise it every day, we can achieve great things for ourselves and for our society.",
  "To sum up, {topic} has many benefits for individuals and communities. Let us carry its lessons forward and make it a regular part of our daily routine.",
  "In the end, {topic} reminds us that small efforts matter. With sincerity and patience, every student can make a meaningful difference.",
  "All in all, {topic} is not only important but also inspiring. It encourages us to be better people and to build a brighter future.",
  "To conclude, {topic} deserves our respect and attention. By learning from it and sharing its values, we can create a happier and more peaceful world.",
  "In short, {topic} shapes who we are and who we will become. Let us embrace it with a positive mind and an open heart.",
  "Finally, we must remember that {topic} is a journey, not a destination. Every step we take with care and honesty brings us closer to success.",
  "So, to wrap up, {topic} is a lesson for all ages. When we value it, we give the next generation a stronger foundation to stand on.",
];

// ---------- WORKOUT & DIET (general plan only, not medical advice) ----------

export type Goal = "lose" | "gain" | "fit";

export const GOALS: { id: Goal; label: string; tip: string }[] = [
  { id: "lose", label: "Lose Weight", tip: "Portion chhota rakhein, cold drinks aur mithai kam karein." },
  { id: "gain", label: "Gain Muscle", tip: "Protein (anda, daal, chicken, doodh) aur roti thodi zyada lein." },
  { id: "fit", label: "Stay Fit", tip: "Balanced plate rakhein: roti/chawal + daal/chicken + sabzi + salad." },
];

export const WORKOUT_DATA: {
  morning: Record<Goal, { icon: string; text: string }[]>;
  evening: Record<Goal, { icon: string; text: string }[]>;
  breakfast: Record<Goal, string[]>;
  lunch: Record<Goal, string[]>;
  dinner: Record<Goal, string[]>;
} = {
  morning: {
    lose: [
      { icon: "🚶", text: "Brisk walk - 30 minutes" },
      { icon: "🤸", text: "Jumping jacks - 3 sets x 30" },
      { icon: "🏃", text: "Light jog - 20 minutes" },
      { icon: "🪢", text: "Skipping rope - 10 minutes" },
      { icon: "🚴", text: "Cycling - 25 minutes" },
      { icon: "🧘", text: "Yoga and stretching - 15 minutes" },
      { icon: "🚶", text: "Brisk walk - 40 minutes" },
    ],
    gain: [
      { icon: "🧘", text: "Warm-up stretching - 10 minutes" },
      { icon: "🚶", text: "Light walk - 15 minutes" },
      { icon: "🤸", text: "Mobility warm-up - 10 minutes" },
      { icon: "🧘", text: "Stretching and breathing - 10 minutes" },
      { icon: "🚶", text: "Light walk - 20 minutes" },
      { icon: "🤸", text: "Warm-up and bodyweight prep - 10 minutes" },
      { icon: "🧘", text: "Light stretch - 10 minutes" },
    ],
    fit: [
      { icon: "🚶", text: "Walk - 25 minutes" },
      { icon: "🧘", text: "Yoga - 15 minutes" },
      { icon: "🏃", text: "Jog - 15 minutes" },
      { icon: "🚴", text: "Cycling - 20 minutes" },
      { icon: "🤸", text: "Full body stretching - 10 minutes" },
      { icon: "🏊", text: "Swimming or brisk walk - 25 minutes" },
      { icon: "🚶", text: "Walk - 30 minutes" },
    ],
  },
  evening: {
    lose: [
      { icon: "🏋️", text: "Squats - 3 x 15" },
      { icon: "💪", text: "Knee push-ups - 3 x 10" },
      { icon: "🧱", text: "Plank - 3 x 30 seconds" },
      { icon: "🪜", text: "Stair climbing - 10 minutes" },
      { icon: "💃", text: "Dance workout - 20 minutes" },
      { icon: "🦵", text: "Lunges - 3 x 10 each leg" },
      { icon: "🌙", text: "Relaxing walk - 20 minutes" },
    ],
    gain: [
      { icon: "💪", text: "Push-ups - 4 x 12" },
      { icon: "🏋️", text: "Squats - 4 x 15" },
      { icon: "💪", text: "Curls with dumbbells or bottles - 3 x 12" },
      { icon: "🎒", text: "Bag rows - 3 x 12" },
      { icon: "🦵", text: "Lunges - 3 x 12" },
      { icon: "🧱", text: "Plank - 3 x 40 seconds" },
      { icon: "🌙", text: "Rest day stretch" },
    ],
    fit: [
      { icon: "🏋️", text: "Squats - 3 x 12" },
      { icon: "💪", text: "Push-ups - 3 x 10" },
      { icon: "🧱", text: "Plank - 3 x 25 seconds" },
      { icon: "🪜", text: "Stairs - 10 minutes" },
      { icon: "💃", text: "Dance or zumba - 20 minutes" },
      { icon: "🦵", text: "Lunges - 3 x 10" },
      { icon: "🌙", text: "Relax and stretch" },
    ],
  },
  breakfast: {
    lose: [
      "Anda (2 eggs) + 1 Roti + green tea",
      "Daal chilla + cucumber",
      "Oats + banana + doodh (low fat)",
      "Chana chaat + lemon water",
      "Egg bhurji (2 eggs) + 1 Roti",
      "Dahi + fruit + 1 Roti",
      "Besan chilla + mint chutney",
    ],
    gain: [
      "Anda (3 eggs) + 2 Roti + 1 glass doodh",
      "Paratha (1) + dahi + 1 anda",
      "Oats + banana + peanut butter + doodh",
      "Chicken sandwich + doodh",
      "Daal + 2 Roti + 2 anday",
      "Chana + Roti + lassi",
      "Anda bhurji (3 eggs) + bread + doodh",
    ],
    fit: [
      "Roti (1-2) + anda + chai (less sugar)",
      "Daal roti + cucumber",
      "Oats + fruit",
      "Chana chaat + chai",
      "Paratha (1, less oil) + dahi",
      "Besan chilla + chutney",
      "Poha or suji + chai",
    ],
  },
  lunch: {
    lose: [
      "Roti (2) + daal + salad",
      "Grilled chicken + Roti (1) + salad",
      "Chicken karahi (less oil) + Roti (1) + salad",
      "Chana daal + Roti + cucumber",
      "Brown rice (1 cup) + daal + sabzi",
      "Chicken salan (less oil) + Roti (1) + salad",
      "Vegetable pulao (small plate) + raita",
    ],
    gain: [
      "Chicken qorma + rice (1 plate) + salad",
      "Roti (3) + daal + chicken boti",
      "Chawal + chicken + dahi",
      "Roti (3) + anda curry + daal",
      "Chicken biryani (1 plate) + raita",
      "Roti (3) + chicken karahi + salad",
      "Rice + daal + anda + salad",
    ],
    fit: [
      "Roti (2) + daal + sabzi + salad",
      "Chicken karahi + Roti (1) + salad",
      "Chawal (1 cup) + chicken + raita",
      "Chana + Roti + salad",
      "Brown rice + daal + sabzi",
      "Roti + chicken salan + salad",
      "Vegetable pulao + raita",
    ],
  },
  dinner: {
    lose: [
      "Light daal + Roti (1)",
      "Vegetable soup + grilled chicken",
      "Chicken sabzi + Roti (1)",
      "Egg bhurji + salad",
      "Chana masala + Roti (1)",
      "Mixed sabzi + dahi",
      "Haleem (small bowl) + salad",
    ],
    gain: [
      "Grilled chicken boti + Roti (2) + daal",
      "Anda curry + Roti (2) + doodh",
      "Chicken qorma + Roti (2)",
      "Daal + rice + chicken tikka",
      "Chicken sabzi + Roti (2) + dahi",
      "Egg bhurji (3 eggs) + Roti (2)",
      "Haleem + Roti + salad",
    ],
    fit: [
      "Daal + Roti (1) + salad",
      "Chicken sabzi + Roti (1)",
      "Vegetable soup + Roti",
      "Egg bhurji + Roti",
      "Chana masala + Roti",
      "Mixed sabzi + dahi",
      "Light chicken karahi + salad",
    ],
  },
};
