// App entry: hash-based router (works on any free static host, including mobile browsers).
import { useEffect, useState } from "react";
import { Navbar } from "./components/Navbar";
import { Footer } from "./components/Footer";
import { Toaster } from "./components/Toaster";
import Home from "./pages/Home";
import { ToolsPage, ToolPage } from "./pages/Tools";
import BlogPage from "./pages/Blog";
import { ForgotPage, LoginPage, SignupPage } from "./pages/Auth";
import HistoryPage from "./pages/History";
import AdminPage from "./pages/Admin";
import { trackVisit } from "./lib/store";

function currentPath(): string {
  return window.location.hash.replace(/^#\/?/, "");
}

export default function App() {
  const [path, setPath] = useState(currentPath());

  useEffect(() => {
    trackVisit();
    const onChange = () => {
      setPath(currentPath());
      window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    };
    window.addEventListener("hashchange", onChange);
    return () => window.removeEventListener("hashchange", onChange);
  }, []);

  const [first, second] = path.split("/");

  if (first === "admin") {
    return (
      <>
        <AdminPage />
        <Toaster />
      </>
    );
  }

  let page;
  switch (first) {
    case "tools":
      page = second ? <ToolPage id={second} /> : <ToolsPage />;
      break;
    case "blog":
      page = <BlogPage />;
      break;
    case "login":
      page = <LoginPage />;
      break;
    case "signup":
      page = <SignupPage />;
      break;
    case "forgot":
      page = <ForgotPage />;
      break;
    case "history":
      page = <HistoryPage />;
      break;
    default:
      page = <Home />;
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar route={first === "tools" || first === "blog" || first === "history" ? first : ""} />
      <main className="flex-1">{page}</main>
      <Footer />
      <Toaster />
    </div>
  );
}
